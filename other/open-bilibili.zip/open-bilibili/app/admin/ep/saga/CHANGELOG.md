# ep-saga
## v2.1.8
> 1.解决企业微信获取user ID为空的问题.

## v2.1.7
> 1.增加branch同步&统计branch聚合数据.

## v2.1.6
> 1.统计mr聚合数据

## v2.1.5
> 1.增加mr同步

## v2.1.4
> 1.adjust some sync time

## v2.1.3
> 1.adjust some data sync code structure

## v2.1.2
> 1.for wechat failed data

## v2.1.1
> 1.for log change

## v2.1.0
> 1.增加同步member、emoji、discussion数据

## v2.0.9
> 1.for pipeline sync

## v2.0.8
> 1.增加note同步数据

## v2.0.7
> 1.pipeline running time 修复 bug

## v2.0.6
> 1.增加企业微信发送记录

## v2.0.5
> 1.调整部分数据的字段以及特殊字符处理

## v2.0.4
> 1.修复企业微信redis存储过期时间

## v2.0.3
> 1.修复企业微信存db报错

## v2.0.2
> 1.恢复先前临时注释的几个gitlab api函数

## v2.0.1
> 1.pipeline异常实时告警

## v2.0.0
> 1.企业微信接口
> 2.数据收集、同步、计算
> 3.sven配置更改（saga）
> 4.pipeline异常实时告警等

## v1.0.4
> 1.增加MR等信息收集和查询接口

## v1.0.3
> 1.增加和优化commit等信息前端查询接口

## v1.0.2
> 1.更改CONTRIBUTORS.md owner

## v1.0.1
> 1.添加定时收集仓库信息的功能

## v1.0.0
> 1.初始化项目
 