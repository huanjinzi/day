# Demo

## 获取App列表
```
POST https://www.pgyer.com/apiv2/app/listMy
```
表单
`_api_key=b97d75cc0c8796d9c552357199c21e71`

```json
{
  "code": 0,
  "message": "",
  "data": {
    "list": [
      {
        "buildKey": "8c3034c748cd8fb0cee9c6e4af26aed9",
        "buildIcon": "50da7b46a463522bf17d1c0f002b9952",
        "buildType": "2",
        "buildFileKey": "6918d2ed99b27d29aa91dbd5fdf5bd55.apk",
        "buildFileName": "Youku_V7.6.3.0123.0001_ab235fdcb823d83f.apk",
        "buildFileSize": "42636294",
        "buildName": "\u4f18\u9177\u89c6\u9891",
        "buildVersion": "7.6.3",
        "buildVersionNo": "183",
        "buildBuildVersion": "1",
        "buildShortcutUrl": "1k2Q",
        "buildIdentifier": "com.youku.phone",
        "buildPassword": "",
        "buildDescription": "",
        "buildUpdateDescription": "",
        "buildLauncherActivity": "",
        "buildScreenshots": "",
        "buildCreated": "2019-02-11 16:57:11",
        "appKey": "9b7194ed9dd5d21a68561be570640bdb",
        "appIsTestFlight": "2",
        "isJoin": "2",
        "isMerged": 2
      }
    ],
    "count": "1",
    "pageCount": 1,
    "page": 1
  }
}
```