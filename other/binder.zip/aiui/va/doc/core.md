# SDK Wakeup事件的分发流程

## 1.创建WakeupResolver

### 创建一个ResolverName对象WAKEUP，表示WakeupResolver的全局唯一标识符
```
public static final ResolverName WAKEUP = new ResolverName("wakeup");
```

### 创建WakeupResolver类
在`onRequestDirective`中返回`WakeupDirective`，这个`Directive`会被分发到`ModuleManager`，
再由此处分发给对应的模块。`WakeupDirective`的`DirectiveName`为`wakeup`，`ModuleName`也为
`wakeup`，所以，只要向`ModuleManager`注册一个名为`wakeup`，支持`wakeup`指令的模块就能收到
语音SDK的唤醒事件。
```
package com.svr.va.core.resolver.svr;

import com.svr.va.core.resolver.IResolver;
import com.svr.va.core.resolver.ResolverName;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.WakeupDirective;

public class WakeupResolver implements IResolver {
    private static final WakeupDirective WAKEUP = new WakeupDirective();
    @Override
    public Directive onRequestDirective(Object... params) {
        return WAKEUP;
    }

    @Override
    public ResolverName getName() {
        return ResolverName.WAKEUP;
    }
}
```

## 2.实现WakeupModule
自定义Module只要实现WakeupModule就能接收语音SDK的唤醒事件。
```
import com.svr.va.remote.directive.WakeupDirective;
import com.svr.va.remote.module.WakeupModule;

public class MyWakeup extends WakeupModule {
    private String TAG = "va_MyWakeup";
    @Override
    public void handleDirective(WakeupDirective directive) {
        Log.w(TAG, "on wakeup...");
    }
}
```

## 3.监听Wakeup事件
在`AIUIListener`中监听Wakeup事件，把Wakeup事件提交给对应的Resolver
```
VAServiceInternal.INSTANCE.submit(ResolverName.WAKEUP);
```

整个事件的传递流程：Listener -> Resolver -> Module