# AIUI
[TOC]
## 技能命名规范

### 技能

技能对应接口(模块)，技能的标识符由(namespace和name)两部分组成：
```
namespace.name
```
`namespace`:建议为公司域名，例如：`com.skyworth`，`com.ssnwt`，(由于AIUI限制，`namespace`不能包
含`.`，而且全为大写，所以建议为`ISKYWORTH`，`ISSNWT`)
`name`:技能的名字，名字以`I`开头，以强调技能对应接口(Interface)，例如：`IDeviceControl`，`IVideo`

```
com.skyworth.IDeviceControl
```

### 意图
意图对应接口中的方法，名字建议以: 动词+名词 的形式，可以多个名词，遵守驼峰规则。

Example:
```
closeBluetooth
lunchApp
adjustVolume
adjustMediaVolume
adjustSystemVolume
```

## 错误码

| 错误码 | 描述 |
| :---:  | :--- |
|  11210 | IvwUnit start error. 更新唤醒sdk时必须替换`assets/ivw/ivw.jet`文件 |

