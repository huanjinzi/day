# Android

## Button
```
<android.support.v7.widget.AppCompatButton
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:onClick="nlp"/>
```

```
//AppCompatActivity
public void nlp(View view) {

}
```

```
<Button
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:onClick="nlp"/>
```

```
//Activity
public void nlp(View view) {

}
```

## Permission
```
private String[] permissions = {
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.CHANGE_NETWORK_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
    };

private static final int CODE = 101;

requestPermissions(permissions,code);
```

```
public void onRequestPermissionsResult(int code, String[] permissions,int[] grant) {
        if (code == CODE) {
            boolean permissionPass = true;
            for (int i = 0; i < permissions.length; i++) {
                if (grant[i] != PackageManager.PERMISSION_GRANTED) {
                    permissionPass = false;
                }
            }

            if (permissionPass) {
                //...
            } else {
                //...
            }
        }
    }
```

## AssetManager
```
// 1
AssetManager mAssetManager = ContextThemeWrapper.getAssets();

// 2
mAssetManager = ContextThemeWrapper.getResources().getAssets();
```

## Context
```
                Context
                /    \
ContextThemeWrapper ContextWrapper
              /       \
      Activity       Application
```

## Application

`Application.onCreate()`可能会被多次调用，比如，`Activity`和`Service`运行在不同的进程中，当Activity
和Service进程启动时，都会调用`Application.onCreate()`

## Service
dump service state.
```
adb shell dumpsys activity service com.svr.va/.core.VAService
```