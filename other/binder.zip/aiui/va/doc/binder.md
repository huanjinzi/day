# Binder
对于Java层有三个重要的类：`IBinder` `Binder` `BinderProxy`，其中`Binder`和`BinderProxy`都实现
了`IBinder`接口。

Binder的特性：

`0` 同步调用
`ONE_WAY` 异步调用

BinderProxy.transact(data,reply) -> Binder.onTransact(data,reply)

data.writeBinderArray(Binder) -> data.readBinderArray(BinderProxy)

pingBinder() -> 进程结束，返回false
isBinderAlive() -> 进程结束，Binder对象还在，返回true

## Binder怎样写boolean值
```
// write
int value = last ? 1 : 0;
dest.writeInt(value);

// read
boolean last = in.readInt() == 1
```
