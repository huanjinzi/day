# Device Control

## 1.音量调节
```
AudioManager mAudioManager = getSystemService(AudioManager.class);
mAudioManager.adjustVolume(
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI |
                        AudioManager.FLAG_PLAY_SOUND);
```

## 2.亮度调节
```
// @RequiresPermission(value = Manifest.permission.WRITE_SETTINGS)
ContentResolver contentResolver = getContentResolver();
Settings.System.putInt(contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, brightness);
```
`WRITE_SETTINGS`权限请求，system uid自动具有此权限
```
int requestCode = 998;
Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
intent.setData(Uri.parse("package:" + getPackageName()));
intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
activity.startActivityForResult(intent, requestCode);
```

## 3.护眼模式
```
// persist.low.blue
Class cls = Class.forName("android.os.SystemProperties");
Method propertySet = cls.getDeclaredMethod("set", String.class,String.class);

// 打开护眼模式，第一个参数为null，调用类的静态方法
propertySet.invoke(null, "persist.low.blue","1");

// 关闭护眼模式
propertySet.invoke(null, "persist.low.blue","0");
```