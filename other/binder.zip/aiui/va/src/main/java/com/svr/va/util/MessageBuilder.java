/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.util;

import com.hz.checker.Checker;
import com.iflytek.aiui.AIUIMessage;

import java.util.Map;

public class MessageBuilder {

    private int msgType;

    private int arg1;

    private int arg2;

    private byte[] data;

    private String paramsStr;


    public MessageBuilder type(int msgType){
        this.msgType = msgType;
        return this;
    }

    public MessageBuilder arg(int arg1){
        this.arg1 = arg1;
        this.arg2 = 0;
        return this;
    }

    public MessageBuilder arg(int arg1,int arg2){
        this.arg1 = arg1;
        this.arg2 = arg2;
        return this;
    }

    public MessageBuilder param(Map<String,String> params) {
        Checker.check(params);
        Checker.check(params.size());
        paramsStr = formatParamString(params);
        return this;
    }

    public MessageBuilder data(byte[] data) {
        this.data = data;
        return this;
    }

    private void reset() {
        this.arg1 = 0;
        this.arg2 = 0;
        paramsStr = null;
        msgType = 0;
        data = null;
    }

    public AIUIMessage build(){
        return new AIUIMessage(msgType, arg1, arg2, paramsStr == null ? null : paramsStr.toString(), data);
    }

    public static String formatParamString(Map<String,String> params) {
        StringBuilder paramsStr = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()
                ) {
            paramsStr.append(entry.getKey());
            paramsStr.append('=');
            paramsStr.append(entry.getValue());
            paramsStr.append(',');
        }
        paramsStr.deleteCharAt(paramsStr.length() - 1);

        return paramsStr.toString();
    }
}
