/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver.xunfei;

import com.svr.va.util.Log;
import com.svr.va.core.annotation.MayNull;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.module.ModuleName;
import com.svr.va.core.resolver.ResolverName;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NLPResolver extends XFResolver {

    private static final String TAG = "NLPResolver";
    public static final ResolverName NAME = new ResolverName("xunfei.nlp");

    @Override
    public ResolverName getName() {
        return NAME;
    }

    @Override
    public Directive onRequestDirective(Object... params) {
        return onRequestDirective((String) params[0], (byte[]) params[1]);
    }

    private Directive onRequestDirective(String ctrl, @MayNull byte[] data) {
        Log.d(TAG, ctrl);

        // ctrl message tell us how to parse data.
        if (data == null) {
            Log.d(TAG, "resolver xunfei." + NLP +" no data.");
            return null;
        }
        String format = "";
        String encode = "";

        try {
            JSONObject ctrlJ = new JSONObject(ctrl);
            format = ctrlJ.optString(XFResolver.CTRL_CONTENT_FORMAT);
            encode = ctrlJ.optString(XFResolver.CTRL_CONTENT_ENCODING);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.w(TAG, "format:" + format);
        if (!format.equals("json") || !encode.equals("utf8")) {
            Log.w(TAG, "resolver " + NAME + " only deal with audio/L16;rate=16000 pcm.");
            return null;
        }

        // default is utf-8
        String dataStr = new String(data);

        Log.d(TAG, dataStr);
        String intent = "";
        int responseCode = -1;
        try {
            JSONObject dataJ = new JSONObject(dataStr);
            intent = dataJ.optString(XFResolver.DATA_INTENT);

            JSONObject intentJ = new JSONObject(intent);
            responseCode = intentJ.optInt(XFResolver.DATA_INTENT_RESPONSE_CODE);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        switch (responseCode) {
            case XFResolver.INTENT_RESPONSE_SUCCESS:
                return handleSuccessIntent(intent);

            case XFResolver.INTENT_RESPONSE_INPUT_ERROR:
                handleInputError();
                break;

            case XFResolver.INTENT_RESPONSE_INTERNAL_ERROR:
                handleInternalError();
                break;

            case XFResolver.INTENT_RESPONSE_REQUEST_FAIL:
                handleRequestFail();
                break;

            case XFResolver.INTENT_RESPONSE_UNKNOWN:
                handleUnknownIntent(intent);
                break;
        }

        return null;
    }

    private Directive handleSuccessIntent( String intent) {

        String module = "";
        try {
            JSONObject responseJ = new JSONObject(intent);
            //rc = responseJ.getInt(XFResolver.DATA_INTENT_RESPONSE_CODE);
            module = responseJ.optString(XFResolver.DATA_INTENT_SERVICE);
            //semantic = responseJ.optString(XFResolver.DATA_INTENT_SEMANTIC);

            //text = responseJ.optString(XFResolver.DATA_INTENT_TEXT);

            JSONArray semanticJA = responseJ.getJSONArray(XFResolver.DATA_INTENT_SEMANTIC);
            JSONObject semanticJ = semanticJA.getJSONObject(0);
            intent = semanticJ.optString(XFResolver.DATA_INTENT_SEMANTIC_INTENT);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (intent.trim().isEmpty()) {
            return null;
        }

        DirectiveName directiveName = new DirectiveName(intent);
        ModuleName moduleName = new ModuleName(module);
        return new Directive(directiveName,moduleName);
    }


    private void handleInputError() {
        Log.w(TAG, "aiui input error.");
    }

    private void handleInternalError() {
        Log.w(TAG, "aiui sdk internal error.");
    }

    private void handleRequestFail() {
        Log.w(TAG, "aiui request fail.");
    }

    private void handleUnknownIntent(String intent) {
        Log.w(TAG, "aiui can't understand intent "+ intent);
    }
}
