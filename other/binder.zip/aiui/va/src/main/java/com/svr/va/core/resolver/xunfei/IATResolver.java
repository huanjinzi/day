package com.svr.va.core.resolver.xunfei;

import com.svr.va.util.Log;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.IATDirective;
import com.svr.va.core.resolver.ResolverName;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class IATResolver extends XFResolver {

    public static final String TAG = "IATResolver";
    public static final ResolverName NAME = new ResolverName("xunfei.iat");

    @Override
    public ResolverName getName() {
        return NAME;
    }

    @Override
    public Directive onRequestDirective(Object... params) {
        return onRequestDirective((String) params[0], (byte[]) params[1]);
    }

    private Directive onRequestDirective(String ctrl, byte[] data) {
        Log.d(TAG, ctrl);

        // ctrl message tell us how to parse data.
        if (data == null) {
            Log.d(TAG, "resolver " + NAME + " no data.");
            return null;
        }

        String format = "";
        String encode = "";

        try {
            JSONObject ctrlJ = new JSONObject(ctrl);
            format = ctrlJ.optString(XFResolver.CTRL_CONTENT_FORMAT);
            encode = ctrlJ.optString(XFResolver.CTRL_CONTENT_ENCODING);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.w(TAG, "format:" + format);
        if (!format.equals("json") || !encode.equals("utf8")) {
            Log.w(TAG, "resolver " + NAME + " only deal with json utf8.");
            return null;
        }

        String dataStr = new String(data);


        boolean last = true;
        StringBuilder text = new StringBuilder();
        try {
            JSONObject dataJ = new JSONObject(dataStr);
            JSONObject textJ =  dataJ.getJSONObject(XFResolver.DATA_TEXT);
            last = textJ.optBoolean("ls");

            JSONArray wsJA = textJ.getJSONArray("ws");
            int length = wsJA.length();
            /*
                {"bg":0,"cw":[{"sc":0.00,"w":"给"}]}
             */
            for (int i = 0; i < length; i++) {
                JSONObject wsJ =  wsJA.getJSONObject(i);
                JSONObject cwJ = wsJ.getJSONArray("cw").getJSONObject(0);
                text.append(cwJ.optString("w"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        /*
            {"sn":22,"ls":true,"bg":0,"ed":0,"pgs":"apd","ws":[{"bg":0,"cw":[{"sc":0.00,"w":"。"}]}]}
         */
        Log.w(TAG, "iat:" + dataStr);
        IATDirective directive = new IATDirective();
        directive.last = last;
        directive.text = text.toString();
        return directive;
    }
}
