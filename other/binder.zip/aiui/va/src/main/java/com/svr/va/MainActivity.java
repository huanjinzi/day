/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;

import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIMessage;
import com.svr.va.remote.IVAService;
import com.svr.va.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class MainActivity extends BaseActivity {

    private static final String TAG = "MainActivity";

    private IVAService mService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent serviceIntent = new Intent();
        ComponentName componentName = new ComponentName(BuildConfig.APPLICATION_ID, VAService.class.getName());
        serviceIntent.setComponent(componentName);
        /*
        bindService(serviceIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Log.i(TAG, "onServiceConnected");
                mService = IVAService.Stub.asInterface(service);
                mService.registerModule(new IAT());
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.i(TAG, "onServiceDisconnected");
                mService = null;
            }

            @Override
            public void onBindingDied(ComponentName name) {
                Log.w(TAG, "onBindingDied");
            }
        }, BIND_AUTO_CREATE);*/
    }

    public void query() {
        return;
    }


    public void nlp(View view) {
        Intent serviceIntent = new Intent();
        ComponentName componentName = new ComponentName(BuildConfig.APPLICATION_ID, VAService.class.getName());
        serviceIntent.setComponent(componentName);
        startService(serviceIntent);
    }

    public void query(View view) {
        Log.i(TAG,"post query" );
        App.IOHandler.postDelayed(this::query, 5000);
    }

    private void syncData() {
        try {
            JSONObject syncSchemaJson = new JSONObject();

            JSONObject paramJson = new JSONObject();

            paramJson.put("id_name", "uid");
            paramJson.put("res_name", "HUANJINZI.app_list");

            syncSchemaJson.put("param", paramJson);

            String data = "{\"appName\": \"微信\",\"alias\": \"wechat\"}\n" +
                    "{\"appName\": \"新浪微博\", \"alias\": \"微博\"}\n" +
                    "{\"appName\": \"Telegram\", \"alias\": \"电报\"}\n" +
                    "{\"appName\": \"讯飞输入法\", \"alias\": \"\"}\n";

            syncSchemaJson.put("data", Base64.encodeToString(data.getBytes(), Base64.DEFAULT | Base64.NO_WRAP));

            byte[] syncData = null;
            Log.i(TAG, syncSchemaJson.toString());
            syncData = syncSchemaJson.toString().getBytes("utf-8");

            AIUIMessage syncAthenaMessage = new AIUIMessage(AIUIConstant.CMD_SYNC, AIUIConstant.SYNC_DATA_SCHEMA, 0, "", syncData);
            App.AIUI.sendMessage(syncAthenaMessage);
        } catch (JSONException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

}
