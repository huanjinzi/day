package com.svr.va.core.listener;

import com.svr.va.util.Log;
import com.svr.va.core.annotation.Singleton;
import com.svr.va.core.listener.xunfei.AIUIListener;

import java.util.HashMap;
import java.util.Map;

@Singleton
public enum SDKListenerManager {

    INSTANCE;

    private static final String TAG = "SDKListenerManager";
    /** modules registered to this service,directive will dispatch to module.*/
    private Map<SDKName, SDKListener> listeners = new HashMap<>();

    /** modules access lock*/
    private final Object listenersLock = new Object();

    // todo add sdk listener.
    {
        registerSDKListener(new AIUIListener(SDKName.XUNFEI));
    }

    public  void registerSDKListener(SDKListener listener) {
        SDKName name  = listener.getName();

        if (listeners.containsKey(name)) {
            throw new RuntimeException("sdk listener has registered." + name);
        }
        synchronized (listenersLock) {
            listeners.put(name, listener);
        }
    }

    public void unregisterSDKListener(SDKListener listener) {
        SDKName name = listener.getName();

        if (!listeners.containsKey(name)) {
            throw new RuntimeException("sdk listener hasn't registered. " + name);
        }
        synchronized (listenersLock) {
            listeners.remove(name);
        }
    }

    public SDKListener getSDKListener(SDKName name) {
        if (!listeners.containsKey(name)) {
            Log.w(TAG, "not find sdk listener:" + name);
            return null;
        }

        synchronized (listenersLock) {
            return listeners.get(name);
        }
    }
}
