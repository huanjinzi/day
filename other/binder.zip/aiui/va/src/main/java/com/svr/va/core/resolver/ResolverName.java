/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver;

import com.svr.va.remote.InterfaceName;

public class ResolverName extends InterfaceName {

    public ResolverName(String fullName) {
        super(fullName);
    }

    public static final ResolverName WAKEUP = new ResolverName("wakeup");
}
