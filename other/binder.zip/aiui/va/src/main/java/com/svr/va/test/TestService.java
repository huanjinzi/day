package com.svr.va.test;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

public class TestService extends Service {

    String TAG = "IntentPerformanceTest";
    TestServiceStub stub = new TestServiceStub();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind");
        return stub;
    }
}
