/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import com.svr.va.remote.IModule;
import com.svr.va.remote.IVAService;
import com.svr.va.remote.SDKConfig;
import com.svr.va.util.Log;

public class VAServiceStub extends IVAService.Stub {
    private static final String TAG = "VAServiceStub";
    private static final VAServiceStub instance = new VAServiceStub();

    public static VAServiceStub getInstance() {
        return instance;
    }

    @Override
    public void registerModule(IModule module) {
        VAServiceInternal.INSTANCE.registerModule(module);
    }

    @Override
    public void unregisterModule(IModule module) {
        VAServiceInternal.INSTANCE.unregisterModule(module);
    }

    public void updateSDKConfig(SDKConfig config) {
        VAServiceInternal.INSTANCE.updateSDKConfig(config);
    }

    @Override
    public void wakeup() {
        VAServiceInternal.INSTANCE.wakeup();
    }

    IBinder[] binderProxies = new IBinder[1];
    @Override
    protected boolean onTransact(int code,Parcel data, Parcel reply, int flags) throws RemoteException {
        // impl in stub sub-class.
        IBinder binderProxy;
        IModule module;
        switch (code) {
            case INTERFACE_TRANSACTION:
                reply.writeString(DESCRIPTOR);
                return true;
            case TRANSACTION_registerModule:
                try {
                    data.enforceInterface(DESCRIPTOR);
                    data.readBinderArray(binderProxies);

                    // Binder Proxy as remote in IModule.Stub.Proxy.
                    binderProxy = binderProxies[0];

                    // IModule.Stub.Proxy.
                    module = IModule.Stub.asInterface(binderProxy);
                    module.setUid(getCallingUid());
                    registerModule(module);
                } catch (Exception e) {
                    Log.e(TAG, e.getMessage(),e);
                    return false;
                }
                return true;

            case TRANSACTION_unregisterModule:
                data.enforceInterface(DESCRIPTOR);
                data.readBinderArray(binderProxies);

                // Binder Proxy as remote in IModule.Stub.Proxy.
                binderProxy = binderProxies[0];

                // IModule.Stub.Proxy.
                module = IModule.Stub.asInterface(binderProxy);
                module.setUid(getCallingUid());
                unregisterModule(module);
                return true;

            case TRANSACTION_wake:
                data.enforceInterface(DESCRIPTOR);
                wakeup();
                return true;
        }
        return super.onTransact(code, data, reply, flags);
    }
}
