/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import com.svr.va.core.resolver.svr.WakeupResolver;
import com.svr.va.remote.directive.Directive;
import com.svr.va.util.Log;
import com.svr.va.core.annotation.Singleton;
import com.svr.va.core.resolver.xunfei.IATResolver;
import com.svr.va.core.resolver.xunfei.NLPResolver;
import com.svr.va.core.resolver.xunfei.TTSResolver;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

@Singleton
public enum  ResolverManager implements IResolverManager {
    INSTANCE;

    private static final String TAG = "ResolverManager";
    private Map<ResolverName, IResolver> resolvers = new HashMap<>();

    private HandlerThread RMThread;
    private Handler RMHandler;
    private Looper looper;
    private CountDownLatch requestDirectiveLatch;

    private Thread.UncaughtExceptionHandler RMThreadExceptionHandler = (t, e) -> {
        Log.e(TAG,"resolver manager thread error,restart.");
        requestDirectiveLatch.countDown();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }

        init();
    };

    {
        init();
        registerResolver(new NLPResolver());
        registerResolver(new TTSResolver());
        registerResolver(new IATResolver());
        registerResolver(new WakeupResolver());
    }

    private void init() {
        RMThread = new HandlerThread("ResolverManager");
        RMThread.setUncaughtExceptionHandler(RMThreadExceptionHandler);
        RMThread.start();
        looper = RMThread.getLooper();
        RMHandler = new Handler(looper);
    }

    @Override
    public Directive requestDirective(ResolverName resolverName, Object... objects) {
        final Directive[] directive = new Directive[1];
        requestDirectiveLatch = new CountDownLatch(1);

        if (!RMHandler.post(() -> {
            directive[0] =
                    requestDirectiveInternal(resolverName, objects);
            requestDirectiveLatch.countDown();
        })) {
            requestDirectiveLatch.countDown();
        }

        try {
            requestDirectiveLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return directive[0];
    }

    public Directive requestDirectiveInternal(ResolverName resolverName, Object... objects) {
        if (resolverName == null) {
            Log.w(TAG, "request resolver name is null.");
            return null;
        }

        if (!resolvers.containsKey(resolverName)) {
            Log.d(TAG, "resolver:" + resolverName + " not registered.");
            return null;
        }

        IResolver resolver;
        resolver = resolvers.get(resolverName);
        return resolver.onRequestDirective(objects);
    }

    @Override
    public void registerResolver(IResolver resolver) {
        RMHandler.post(() -> registerResolverInternal(resolver));
    }


    public void registerResolverInternal(IResolver resolver) {
        if (resolver == null) {
            Log.d(TAG, "register resolver is null.");
            return;
        }
        ResolverName name = resolver.getName();

        if (name == null) {
            Log.d(TAG, "register resolver name is null.");
            return;
        }

        if (resolvers.containsKey(name)) {
            Log.w(TAG,"resolver has registered." + name);
            return;
        }

        resolvers.put(name, resolver);
    }

    @Override
    public void unregisterResolver(IResolver resolver) {
        RMHandler.post(() -> unregisterResolverInternal(resolver));
    }

    public void unregisterResolverInternal(IResolver resolver) {
        if (resolver == null) {
            Log.d(TAG, "register resolver is null.");
            return;
        }
        ResolverName name = resolver.getName();

        if (name == null) {
            Log.d(TAG, "register resolver name is null.");
            return;
        }

        if (!resolvers.containsKey(name)) {
            Log.w(TAG,"resolver hasn't registered. " + name);
            return;
        }
        resolvers.remove(name);
    }

    public void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        writer.write("\nResolverManager State:\n");
    }
}
