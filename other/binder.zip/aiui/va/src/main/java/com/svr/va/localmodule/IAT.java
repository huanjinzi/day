package com.svr.va.localmodule;

import com.svr.va.util.Log;
import com.svr.va.remote.directive.IATDirective;
import com.svr.va.remote.module.IATModule;

public class IAT extends IATModule {
    String TAG = "IATModule";

    @Override
    public void handleDirective(IATDirective directive) {
        Log.d(TAG, "iat:" + directive.text + " " + directive.last);
    }
}
