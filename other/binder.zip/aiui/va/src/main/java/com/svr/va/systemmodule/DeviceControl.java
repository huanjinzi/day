/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.systemmodule;

import android.Manifest;
import android.content.ContentResolver;
import android.media.AudioManager;
import android.provider.Settings;
import android.support.annotation.RequiresPermission;

import com.svr.va.App;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.module.Module;
import com.svr.va.remote.module.ModuleName;
import com.svr.va.util.Log;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class DeviceControl extends Module {

    private final static String TAG = "DeviceControl";
    private static ModuleName name = new ModuleName("ISKYWORTH.IDeviceControl");

    private static final DirectiveName BRIGHTNESS_UP = new DirectiveName("brightnessUp");
    private static final DirectiveName BRIGHTNESS_DOWN = new DirectiveName("brightnessDown");

    private static final DirectiveName VOLUME_UP = new DirectiveName("volumeUp");
    private static final DirectiveName VOLUME_DOWN = new DirectiveName("volumeDown");

    private static final DirectiveName EYE_PROTECTION_ON = new DirectiveName("eyeProtectionOn");
    private static final DirectiveName EYE_PROTECTION_OFF = new DirectiveName("eyeProtectionOff");

    private static final DirectiveName WIFI_ON = new DirectiveName("wifiOn");
    private static final DirectiveName WIFI_OFF = new DirectiveName("wifiOff");

    private AudioManager mAudioManager;
    private Method propertySet;

    private static final String PROPERTY_EYE_PROTECTION_KEY = "persist.low.blue";

    public DeviceControl() {
        mAudioManager = App.get().getSystemService(AudioManager.class);
        Class cls = null;
        try {
            cls = Class.forName("android.os.SystemProperties");
        } catch (ClassNotFoundException e) {
            Log.e(TAG, "android.os.SystemProperties not found");
            e.printStackTrace();
        }

        if (cls != null) {
            try {
                propertySet = cls.getDeclaredMethod("set", String.class,String.class);
            } catch (NoSuchMethodException e) {
                Log.e(TAG, "SystemProperties no set method found");
                e.printStackTrace();
            }
        }

    }

    private ArrayList supportDirective = new ArrayList() {
        {
            add(BRIGHTNESS_UP);
            add(BRIGHTNESS_DOWN);

            add(VOLUME_UP);
            add(VOLUME_DOWN);

            add(EYE_PROTECTION_ON);
            add(EYE_PROTECTION_OFF);

            add(WIFI_ON);
            add(WIFI_OFF);
        }
    };

    @Override
    public void handleDirective(Directive directive) {
        DirectiveName name = directive.getName();

        if (name.equals(BRIGHTNESS_UP))
            onBrightnessUp();

        else if (name.equals(BRIGHTNESS_DOWN))
            onBrightnessDown();

        else if (name.equals(VOLUME_UP))
            onVolumeUp();

        else if (name.equals(VOLUME_DOWN))
            onVolumeDown();

        else if (name.equals(WIFI_ON))
            onWifiOn();

        else if (name.equals(WIFI_OFF))
            onWifiOff();

        else if (name.equals(EYE_PROTECTION_ON))
            setEyeProtection(true);

        else if (name.equals(EYE_PROTECTION_OFF))
            setEyeProtection(false);
    }

    @Override
    public List<DirectiveName> supportDirective() {
        return supportDirective;
    }

    @Override
    public ModuleName getName() {
        return name;
    }

    private void setEyeProtection(boolean on) {
        if (propertySet == null) return;
        String value = on ? "1" : "0";
        try {
            propertySet.invoke(null, PROPERTY_EYE_PROTECTION_KEY,value);
        } catch (IllegalAccessException | InvocationTargetException e) {
            Log.e(TAG, "set eye protection fail.");
            e.printStackTrace();
        }
    }

    private void onWifiOn() {

    }

    private void onWifiOff() {

    }

    private void onVolumeUp() {
        mAudioManager.adjustVolume(
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI |
                        AudioManager.FLAG_PLAY_SOUND);
    }

    private void onVolumeDown() {
        mAudioManager.adjustVolume(
                AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI |
                        AudioManager.FLAG_PLAY_SOUND);
    }

    private void onBrightnessUp() {
        int current = getBrightness();

        int dest = current + 55;

        if (dest > 255) {
            dest = 255;
        }

        Log.d(TAG, String.format("onBrightnessUp current=%d，dest=%d", current, dest));
        saveBrightness(dest);
    }

    private void onBrightnessDown() {
        int current = getBrightness();

        int dest;
        if (current < 35) {
            dest = 0;
        } else {
            dest = current - 35;
        }
        Log.d(TAG, String.format("onBrightnessDown current=%d,dest=%d", current, dest));
        saveBrightness(dest);
    }


    @RequiresPermission(value = Manifest.permission.WRITE_SETTINGS)
    private void saveBrightness(int brightness) {
        if (brightness < 0 || brightness > 255) {
            brightness = 127;
        }
        setScreenManualMode();
        ContentResolver contentResolver = App.get().getContentResolver();
        Settings.System.putInt(contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, brightness);
    }

    @RequiresPermission(value = Manifest.permission.WRITE_SETTINGS)
    private void setScreenManualMode() {
        ContentResolver contentResolver = App.get().getContentResolver();
        try {
            int mode = Settings.System.getInt(contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE);
            if (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            }
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
    }

    private int getBrightness() {
        ContentResolver contentResolver = App.get().getContentResolver();
        int defVal = 125;
        return Settings.System.getInt(contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, defVal);
    }
}
