/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core;

import com.svr.va.core.annotation.Singleton;
import com.svr.va.core.config.ConfigManager;
import com.svr.va.core.module.ModuleManager;
import com.svr.va.core.resolver.ResolverManager;
import com.svr.va.core.resolver.ResolverName;
import com.svr.va.remote.IModule;
import com.svr.va.remote.SDKConfig;
import com.svr.va.remote.directive.Directive;
import com.svr.va.util.Log;

import java.io.FileDescriptor;
import java.io.PrintWriter;

@Singleton
public enum  VAServiceInternal implements OnDirectiveListener {
    INSTANCE;
    private static final String TAG = "VAServiceInternal";

    @Override
    public boolean onDirective(Directive directive) {
        Log.d(TAG, "onDirective:" + directive.getName());
        return false;
    }

    public void submit(ResolverName resolverName, Object... params) {
        Log.d(TAG, "submit:" + resolverName);
        Directive directive;
        directive = ResolverManager.INSTANCE.requestDirective(resolverName, params);
        ModuleManager.INSTANCE.sendDirective(directive);
    }

    public void registerModule(IModule module) {
        ModuleManager.INSTANCE.registerModule(module);
    }

    public void unregisterModule(IModule module) {
        ModuleManager.INSTANCE.unregisterModule(module);
    }

    public void updateSDKConfig(SDKConfig config) {
        Log.d(TAG, "updateSDKConfig:" + config.getName());
    }

    public void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        ResolverManager.INSTANCE.dump(fd, writer, args);
        ModuleManager.INSTANCE.dump(fd,writer,args);
    }

    public void wakeup() {
        ConfigManager.reset();
        ConfigManager.wakeup();
        // send record cmd.
        ConfigManager.startRecord();
    }
}
