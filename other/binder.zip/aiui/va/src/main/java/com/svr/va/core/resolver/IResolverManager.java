/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver;

import com.svr.va.remote.directive.Directive;

public interface IResolverManager {


    Directive requestDirective(ResolverName resolverName, Object ... objects);

    /**
     * register resolver,when service dispatch directive,corresponding module's
     * <code> handleDirective()</> method will be called. this method is thread
     * safe.
     * @param resolver module added to service.
     * @throws RuntimeException module has registered.
     * */
    void registerResolver(IResolver resolver);


    /**
     * this method is thread safe.
     * @param resolver the module removed from this service.
     * @throws RuntimeException module hasn't registered.
     */
    void unregisterResolver(IResolver resolver);
}
