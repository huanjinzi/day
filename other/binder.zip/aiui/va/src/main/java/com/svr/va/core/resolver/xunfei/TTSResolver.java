package com.svr.va.core.resolver.xunfei;

import com.svr.va.util.Log;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.TTSDirective;
import com.svr.va.core.resolver.ResolverName;

import org.json.JSONException;
import org.json.JSONObject;

public class TTSResolver extends XFResolver {

    private static final String TAG = "TTSResolver";
    public static final ResolverName NAME = new ResolverName("xunfei.tts");

    @Override
    public ResolverName getName() {
        return NAME;
    }

    @Override
    public Directive onRequestDirective(Object... params) {
        return onRequestDirective((String) params[0], (String) params[1], (int)params[2], (byte[]) params[3]);
    }

    private Directive onRequestDirective(String ctrl, String sid, int percent, byte[] audio) {
        Log.d(TAG, ctrl);
        /*
        * {"cancel":"0","cnt_id":"0","dte":"pcm","dtf":"audio/L16;rate=16000","dts":1,
        * "error":"","frame_id":5,"text_end":24,"text_percent":28,"text_seg":"成都今天全天晴转小雨，"
        * ,"text_start":0}
        */

        // ctrl message tell us how to parse data.
        if (audio == null) {
            Log.d(TAG, "resolver " + NAME.toString() + " no audio.");
            return null;
        }
        String format = "";
        String encode = "";
        String text = "";
        boolean cancel = false;
        int state = -1;

        try {
            JSONObject ctrlJ = new JSONObject(ctrl);
            format = ctrlJ.optString(XFResolver.CTRL_CONTENT_FORMAT);
            encode = ctrlJ.optString(XFResolver.CTRL_CONTENT_ENCODING);
            cancel = Integer.toString(1).equals(ctrlJ.optString(XFResolver.CTRL_CONTENT_TTS_CANCEL));
            text = ctrlJ.optString("text_seg");
            state = ctrlJ.getInt("dts");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.w(TAG, "format:" + format);
        Log.w(TAG, "encode:" + encode);
        Log.w(TAG, "audio:" + audio.length);
        if (!format.equals("audio/L16;rate=16000") || !encode.equals("pcm")) {
            Log.w(TAG, "resolver " + NAME.toString() + " only deal with audio/L16;rate=16000 pcm.");
            return null;
        }

        String[] f=  format.split("[;]");

        String[] m = f[0].split("[/][L]");

        String media = m[0];
        String bit = m[1];
        Log.d(TAG, "media=" + media + " bit=" + bit);

        String[] entry = f[1].split("[=]");
        String key = entry[0];
        String value = entry[1];
        Log.d(TAG, "key=" + key + " value=" + value);

        TTSDirective directive = new TTSDirective();

        directive.sid = sid;
        directive.percent = percent;
        directive.audio = audio;
        directive.cancel = cancel;
        directive.rate = Integer.valueOf(value);
        directive.bit = Integer.valueOf(bit);
        directive.text = text;
        directive.state = state;
        return directive;
    }
}
