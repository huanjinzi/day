/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.module;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.IModule;

/**
 * <code> ModuleManager </> is implement this interface.
 */
public interface IModuleManager {

    /**
     * register module,when service dispatch directive,corresponding module's
     * <code> handleDirective()</> method will be called. this method is thread
     * safe.
     * @param module module added to service.
     * */
    void registerModule(IModule module);

    /**
     * this method is thread safe.
     * @param module the module removed from this service.
     */
    void unregisterModule(IModule module);


    /**
     * when resolver parse sdk listener params complete,VAServiceInternal will get directive from
     * resolver,and send directive to module manager.
     * @param directive send to module manager.*/
    void sendDirective(Directive directive);

}
