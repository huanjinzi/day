/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.listener.xunfei;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;

import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIEvent;
import com.svr.va.App;
import com.svr.va.R;
import com.svr.va.core.VAServiceInternal;
import com.svr.va.core.listener.SDKListener;
import com.svr.va.core.listener.SDKName;
import com.svr.va.core.resolver.ResolverName;
import com.svr.va.core.resolver.xunfei.IATResolver;
import com.svr.va.core.resolver.xunfei.NLPResolver;
import com.svr.va.core.resolver.xunfei.TTSResolver;
import com.svr.va.core.resolver.xunfei.XFResolver;
import com.svr.va.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AIUIListener extends SDKListener implements com.iflytek.aiui.AIUIListener {
    private static final String TAG = "AIUIListener";
    private MediaPlayer mDingPlayer;
    private AudioManager mAudioManager;
    private int mTtsBufferProgress;


    public AIUIListener(SDKName name) {
        super(name);
        mDingPlayer =  MediaPlayer.create(App.get(), R.raw.ding);
        mAudioManager = App.get().getSystemService(AudioManager.class);
        mDingPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mDingPlayer.setVolume(1.0f,1.0f);
    }

    @Override
    public void onEvent(AIUIEvent event) {
        switch (event.eventType) {

            case AIUIConstant.EVENT_RESULT:
                App.IOHandler.post(() -> onResult(event));
                break;

            case AIUIConstant.EVENT_ERROR:
                App.IOHandler.post(() -> onError(event));
                break;

            case AIUIConstant.EVENT_STATE:
                App.IOHandler.post(() -> onStateChange(event));
                break;

            case AIUIConstant.EVENT_WAKEUP:
                App.IOHandler.post(() -> onWakeUp(event));
                break;

            case AIUIConstant.EVENT_SLEEP:
                App.IOHandler.post(() -> onSleep(event));
                break;

            case AIUIConstant.EVENT_VAD:
                App.IOHandler.post(() -> onVoiceActivity(event));
                break;

            case AIUIConstant.EVENT_CMD_RETURN:
                App.IOHandler.post(() -> onCommandReturn(event));
                break;

            case AIUIConstant.EVENT_PRE_SLEEP:
                App.IOHandler.post(() -> onPreSleep(event));
                break;

            case AIUIConstant.EVENT_START_RECORD:
                App.IOHandler.post(() -> onStartRecord(event));
                break;

            case AIUIConstant.EVENT_STOP_RECORD:
                App.IOHandler.post(() -> onStopRecord(event));
                break;

            case AIUIConstant.EVENT_CONNECTED_TO_SERVER:
                App.IOHandler.post(() -> onServerConnected(event));
                break;

            case AIUIConstant.EVENT_SERVER_DISCONNECTED:
                App.IOHandler.post(() -> onServerDisconnected(event));
                break;

            case AIUIConstant.EVENT_TTS:
                App.IOHandler.post(() -> onTTS(event));
                break;

                default:
                    Log.w(TAG, "unknown event received.");
        }
    }

    private void onResult(AIUIEvent event) {
        String ctrl = event.info;
        Bundle bundle = event.data;

        // every response include ctrl+data.
        String resolverName;
        String cnt_id;
        String content;

        // 1.parse ctrl's content and param.
        JSONObject contentJ;
        JSONObject paramsJ;
        try {
            JSONObject ctlJ = new JSONObject(ctrl);
            JSONArray ctrlDataJA = ctlJ.getJSONArray(XFResolver.CTRL_DATA);
            JSONObject ctrlDataJ = ctrlDataJA.getJSONObject(0);

            paramsJ = ctrlDataJ.getJSONObject(XFResolver.CTRL_PARAMS);

            JSONArray contentJA = ctrlDataJ.getJSONArray(XFResolver.CTRL_CONTENT);
            contentJ = contentJA.getJSONObject(0);
            cnt_id = contentJ.optString(XFResolver.CTRL_CONTENT_ID);
            content = contentJ.toString();

        } catch (JSONException e) {
            Log.w(TAG, "ctrl json parse error!");
            return;
        }

        // 2. parse ctrl's param,decide which parse to dispatch.
        resolverName = paramsJ.optString(XFResolver.CTRL_PARAMS_SUBJECT);

        Log.d(TAG, "resolver:" + ctrl);
        /*
         * {"data":[{"content":[{"cancel":"0","cnt_id":"0","dte":"pcm","dtf":"audio/L16;rate=16000",
         * "dts":1,"error":"","frame_id":3,"text_end":24,"text_percent":28,"text_seg":"成都今天全
         * 天晴转小雨，","text_start":0}],"params":{"cmd":"iat-kc-tts","lrst":"0","rstid":1,
         * "sub":"tts"}}]}
         */

        byte[] data = null;
        if (!cnt_id.isEmpty()) {
            data = bundle.getByteArray(cnt_id);
        }

        /* nlp */
        if (resolverName.equals(XFResolver.NLP)) {
            VAServiceInternal.INSTANCE.submit(NLPResolver.NAME, content, data);
            return;
        }

        /* iat */
        if (resolverName.equals(XFResolver.IAT)) {
            VAServiceInternal.INSTANCE.submit(IATResolver.NAME,content,data);
            return;
        }

        /* tts */
        if (resolverName.equals(XFResolver.TTS)) {
            String sid = event.data.getString("sid");
            int percent = event.data.getInt("percent");
            mTtsBufferProgress = percent;
            byte[] audio = data;
            VAServiceInternal.INSTANCE.submit(TTSResolver.NAME, content, sid, percent, audio);
            return;
        }

        Log.e(TAG, "resolver " + resolverName + "not parsed.");
    }

    private void onError(AIUIEvent event) {
        Log.e(TAG, "EVENT_ERROR : " + event.eventType +
                " " + event.arg1 + " " + event.info);
    }

    private void onStateChange(AIUIEvent event) {
        int AIUIState = event.arg1;

        if (AIUIConstant.STATE_IDLE == AIUIState) {
            mAudioManager.abandonAudioFocus(wakeFocusChangeListener);
            Log.i(TAG, "IDLE");
        } else if (AIUIConstant.STATE_READY == AIUIState) {
            Log.i(TAG, "READY");
            mAudioManager.abandonAudioFocus(wakeFocusChangeListener);
        } else if (AIUIConstant.STATE_WORKING == AIUIState) {
            mAudioManager.requestAudioFocus(wakeFocusChangeListener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
            Log.i(TAG, "WORKING");
        }
    }


    private AudioManager.OnAudioFocusChangeListener wakeFocusChangeListener = focusChange -> {};
    private void onWakeUp(AIUIEvent event) {
        mAudioManager.requestAudioFocus(wakeFocusChangeListener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
        if (!mDingPlayer.isPlaying()) {
            mDingPlayer.start();
        }
        VAServiceInternal.INSTANCE.submit(ResolverName.WAKEUP);
        Log.d(TAG, "EVENT_WAKEUP: " + event.eventType);
    }

    private void onSleep(AIUIEvent event) {
        Log.d(TAG, "EVENT_SLEEP: " + event.eventType);
    }

    private void onVoiceActivity(AIUIEvent event) {
        if (AIUIConstant.VAD_BOS == event.arg1) {
            Log.d(TAG, "VAD_BOS");
        } else if (AIUIConstant.VAD_EOS == event.arg1) {
            Log.d(TAG, "VAD_EOS");
        }
    }

    private void onCommandReturn(AIUIEvent event) {
        switch (event.arg1) {
            case AIUIConstant.CMD_SYNC: {
                int d_type = event.data.getInt("sync_dtype");

                //arg2表示结果
                String mSyncSid;
                if (0 == event.arg2) {  // 同步成功
                    if (AIUIConstant.SYNC_DATA_SCHEMA == d_type) {
                        mSyncSid = event.data.getString("sid");
                        Log.i(TAG, "schema数据同步成功，sid=" + mSyncSid);
                    }
                } else {
                    if (AIUIConstant.SYNC_DATA_SCHEMA == d_type) {
                        mSyncSid = event.data.getString("sid");
                        Log.i(TAG, "schema数据同步出错：" + event.arg2 + "，sid=" + mSyncSid);
                    }
                }
            }
            break;

            case AIUIConstant.CMD_QUERY_SYNC_STATUS: {
                int syncType = event.data.getInt("sync_dtype");

                if (AIUIConstant.SYNC_DATA_QUERY == syncType) {
                    String result = event.data.getString("result");

                    if (0 == event.arg2) {
                        Log.i(TAG, "查询结果：" + result);
                    } else {
                        Log.i(TAG, "schema数据状态查询出错：" + event.arg2 + ", result:" + result);
                    }
                }
            }
            break;
        }
    }

    private void onPreSleep(AIUIEvent event) {
        Log.d(TAG, "EVENT_PRE_SLEEP: " + event.eventType);
    }

    private void onStartRecord(AIUIEvent event) {
        Log.d(TAG, "START_RECORD: " + event.eventType);
    }

    private void onStopRecord(AIUIEvent event) {
        Log.d(TAG, "STOP_RECORD: " + event.eventType);
    }

    private void onServerConnected(AIUIEvent event) {
        Log.d(TAG, "ON_SERVER_CONNECTED: " + event.eventType);
    }

    private void onServerDisconnected(AIUIEvent event) {
        Log.d(TAG, "ON_SERVER_DISCONNECTED: " + event.eventType);
    }

    private void onTTS(AIUIEvent event) {
        switch (event.arg1) {
            case AIUIConstant.TTS_SPEAK_BEGIN:
                Log.d(TAG,"开始播放");
                mAudioManager.requestAudioFocus(wakeFocusChangeListener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
                break;

            case AIUIConstant.TTS_SPEAK_PROGRESS:
                Log.d(TAG,"缓冲进度为" + mTtsBufferProgress +
                        ", 播放进度为" + event.data.getInt("percent"));
                break;

            case AIUIConstant.TTS_SPEAK_PAUSED:
                Log.d(TAG,"暂停播放");
                break;

            case AIUIConstant.TTS_SPEAK_RESUMED:
                Log.d(TAG,"恢复播放");
                break;

            case AIUIConstant.TTS_SPEAK_COMPLETED:
                mAudioManager.abandonAudioFocus(wakeFocusChangeListener);
                Log.d(TAG,"播放完成");
                break;
        }
    }
}
