/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.util;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import java.util.HashMap;
import java.util.Map;


import static com.svr.va.App.TAG;

public class PermissionManager {

    private Activity activity;
    private Map<Integer, String[]> permissionsNotGrant = new HashMap<>();
    private Map<Integer, String[]> permissionsGrant = new HashMap<>();

    private Listener listener;

    public PermissionManager(Activity activity) {
        this.activity = activity;
    }

    private boolean allPermissionGranted = false;
    private int writingSettingsRequestCode = 10000;

    private int requestCode = 0;

    public void add(String[] permissions) {
        Log.i(TAG, "add permissions:" + requestCode);
        for (String permission : permissions) {
            Log.w(TAG, permission);
        }
        permissionsNotGrant.put(requestCode, permissions);
        requestCode++;

    }

    public void check() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {


            if (!Settings.System.canWrite(activity)) {
                Log.w(TAG, "special permission:WRITE_SETTINGS");
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));
                //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivityForResult(intent, writingSettingsRequestCode);
            }

            notifyNormalPermissionCheck();
        }
    }

    public void addAllPermissionsGrantedListener(Listener listener) {
        this.listener = listener;
    }

    private void notifyNormalPermissionCheck() {
        for (Map.Entry<Integer, String[]> entry : permissionsNotGrant.entrySet()
                ) {
            activity.requestPermissions(entry.getValue(), entry.getKey());
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean permissionPass = true;

        String permissionNeedRationale = null;

        int permissionPosition = 0;
        for (int grant : grantResults
                ) {
            if (grant != PackageManager.PERMISSION_GRANTED) {
                permissionPass = false;
                permissionNeedRationale = permissions[permissionPosition];
            }
            permissionPosition++;
        }

        if (permissionPass) {
            permissionsGrant.put(requestCode, permissions);
            if (permissionsGrant.size() == permissionsNotGrant.size()) {
                allPermissionGranted = true;
            }

            if (allPermissionGranted) {
                if (listener != null) {
                    listener.onAllPermissionsGranted();
                }
                permissionsGrant.clear();
            }
            return;
        }

        // rationale.
        if (activity.shouldShowRequestPermissionRationale(permissionNeedRationale)) {
            Log.w(TAG, "permission need rationale:" + permissionNeedRationale);
        }

        StringBuilder permissionsNotGrant = new StringBuilder();
        for (String permission : permissions
                ) {
            permissionsNotGrant.append(permission);
            permissionsNotGrant.append('\n');
        }
        Log.w(TAG, "permissions not granted:\n" + permissionsNotGrant.toString());
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == writingSettingsRequestCode) {
            if (Settings.System.canWrite(activity)) {
            }
        }
    }



    public interface Listener {
        void onAllPermissionsGranted();
    }
}
