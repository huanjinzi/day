/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core;

import com.svr.va.remote.directive.Directive;

/**
 * interface listen module handle directive.
 */
public interface OnDirectiveListener {

    boolean onDirective(Directive directive);
}
