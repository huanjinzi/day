/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.svr.va.util.Log;
import com.svr.va.util.PermissionManager;

public class BaseActivity extends AppCompatActivity implements PermissionManager.Listener{

    private static final String TAG = "BaseActivity";

    private String[] AUDIO = {
            Manifest.permission.RECORD_AUDIO
    };

    private String[] STORAGE = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private static String[] NETWORK = {
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.CHANGE_NETWORK_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
    };

    private static String[] WRITE_SETTINGS = {
            Manifest.permission.WRITE_SETTINGS
    };

    private PermissionManager permissionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        if (permissionManager == null) {
            permissionManager = new PermissionManager(this);
            permissionManager.add(AUDIO);
            permissionManager.add(STORAGE);
            permissionManager.add(NETWORK);
            //permissionManager.add(WRITE_SETTINGS);
            permissionManager.addAllPermissionsGrantedListener(this);
        }

        permissionManager.check();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (permissionManager != null) {
            permissionManager.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onAllPermissionsGranted() {
        Log.i(TAG, "onAllPermissionsGranted:aiui init");
        //App.IOHandler.post(App.get()::AIUIInit);
    }
}
