/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.module;

import android.annotation.SuppressLint;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import com.svr.va.util.Log;
import com.svr.va.core.OnDirectiveListener;
import com.svr.va.core.VAServiceInternal;
import com.svr.va.core.annotation.Singleton;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.IModule;
import com.svr.va.remote.module.ModuleName;
import com.svr.va.systemmodule.DeviceControl;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

@Singleton
public enum ModuleManager implements IModuleManager {
    INSTANCE(VAServiceInternal.INSTANCE);
    private static final String TAG = "ModuleManager";

    /**
     * when dispatch directive to this service's module,directive listener will be notified.
     */
    protected ArrayList<OnDirectiveListener> directiveListeners = new ArrayList<>();

    private OnDirectiveListener directiveManagerListener;

    /**
     * local modules registered to this service,directive will dispatch to module.
     */
    private Map<ModuleName, IModule> modules = new HashMap<>();

    /**
     * remote modules registered to this service,directive will dispatch to module.
     */
    @SuppressLint("UseSparseArrays")
    private Map<Integer, Map<ModuleName, IModule>> remoteModules = new HashMap<>();

    /**
     * work thread.
     */
    private HandlerThread MMThread;
    private Handler MMHandler;

    /**
     * dump task latch,local module dump,remote module dump.
     */
    private CountDownLatch dumpLatch;

    private Looper looper;

    /**
     * uncaught exception handler,when error happen,resume handler thread.
     */
    private Thread.UncaughtExceptionHandler MMExceptionHandler = (t, e) -> {
        //clear dump latch.
        if (dumpLatch != null) {
            /* be very careful at here.*/
            long latchCount = dumpLatch.getCount();
            //for (int i = 0; i < dumpLatch.getCount(); i++) {
            for (int i = 0; i < latchCount; i++) {
                /*when countDown() called,getCount() will -1.*/
                dumpLatch.countDown();
            }
        }

        looper.quitSafely();
        init();
        Log.e(TAG, t.getName() + " died,start new workThread.");
    };

    {
        init();
    }

    /* Init Work Thread */
    private void init() {
        MMThread = new HandlerThread("ModuleManagerThread");
        // make MMThread alive
        MMThread.start();
        MMThread.setUncaughtExceptionHandler(MMExceptionHandler);

        // getLooper will wait until looper created.
        looper = MMThread.getLooper();
        MMHandler = new Handler(looper);
    }

    /* Register Module */ {
        registerModule(new DeviceControl());
    }

    ModuleManager(OnDirectiveListener listener) {
        directiveManagerListener = listener;
    }

    @Override
    public void registerModule(IModule module) {
        Log.d(TAG, "registerModule");
        MMHandler.post(() -> registerModuleInternal(module));

    }

    private void registerModuleInternal(IModule module) {
        ModuleName name = module.getName();
        int uid = module.getUid();

        if (name == null) {
            Log.w(TAG, "register module name is null.");
            return;
        }

        if (module.asBinder() instanceof Binder) {
            // local module do not allow repeat.
            Log.d(TAG, "register local module " + module);
            if (modules.containsKey(name)) {
                Log.w(TAG, "local module has been registered " + name);
                return;
            }
            modules.put(name, module);

        } else {
            Log.d(TAG, "register remote module " +
                    module + " uid 0x" + Integer.toHexString(uid));

            if (!remoteModules.containsKey(uid)) {
                remoteModules.put(uid, new HashMap<>());
            }

            if (remoteModules.get(uid).containsKey(name)) {
                if (remoteModules.get(uid).get(name).asBinder().pingBinder()) {
                    // module die,directly override it.
                    Log.w(TAG, "remote module " + name +
                            " has been registered by uid " +
                            Integer.toHexString(uid));
                    return;
                } else {
                    Log.w(TAG, "remote module " + name +
                            " has died,will be override by uid " +
                            Integer.toHexString(uid));
                }
            }
            remoteModules.get(uid).put(name, module);
        }

        clearDie();
    }

    @Override
    public void unregisterModule(IModule module) {
        Log.d(TAG, "unregisterModule");
        MMHandler.post(() -> unregisterModuleInternal(module));

    }

    private void unregisterModuleInternal(IModule module) {
        ModuleName name = module.getName();
        int uid = module.getUid();

        if (module.asBinder() instanceof Binder) {
            Log.d(TAG, "unregister local module " + module);
            // local module do not allow repeat.
            if (!modules.containsKey(name)) {
                Log.w(TAG, "local module hasn't been registered " + name);
                return;
            }
            modules.remove(name);

        } else {
            Log.d(TAG, "unregister remote module " + module);

            if (!remoteModules.containsKey(uid)) {
                Log.w(TAG, "no remote module " +
                        "hasn't been registered by uid " +
                        Integer.toHexString(uid));
                return;
            }

            if (!remoteModules.get(uid).containsKey(name)) {
                Log.w(TAG, "remote module " +
                        "hasn't been registered by uid 0x" +
                        Integer.toHexString(uid));
                return;
            }

            if (remoteModules.get(uid).containsKey(name)) {
                remoteModules.get(uid).remove(name);
            }
        }

        clearDie();
    }

    @Override
    public void sendDirective(Directive directive) {
        Log.d(TAG, "sendDirective");
        MMHandler.post(() -> sendDirectiveInternal(directive));

    }

    private void sendDirectiveInternal(Directive directive) {
        boolean nullDirective = directive == null;
        if (nullDirective) {
            Log.w(TAG, "send directive internal: " +
                    "directive is null");
            return;
        }

        DirectiveName directiveName = directive.getName();
        ModuleName moduleName = directive.getModuleName();

        boolean nullDirectiveName = directiveName == null;
        boolean nullModuleName = moduleName == null;
        if (nullDirectiveName | nullModuleName) {
            Log.w(TAG, "send directive internal: " +
                    "directive name or module name is null.");
            return;
        }

        if (notifyDirectiveManagerListener(directive)) {
            return;
        }

        if (notifyDirectiveListener(directive)) {
            return;
        }

        IModule module;
        List<DirectiveName> supportDirective;

        // notify remote module first.
        boolean findRemoteModuleSupportDirective = false;

        boolean needClearDied = false;
        for (Map.Entry<Integer, Map<ModuleName, IModule>> user :
                remoteModules.entrySet()) {
            if (user.getValue().containsKey(moduleName)) {

                Log.d(TAG, "remote module find:" +
                        moduleName + " uid 0x" +
                        Integer.toHexString(user.getKey()));

                module = user.getValue().get(moduleName);
                // check remote module is alive.
                if (module.asBinder().pingBinder()) {
                    supportDirective = module.supportDirective();

                    if (supportDirective == null) {
                        Log.d(TAG, "remote module:" + module.getName()
                                + " uid 0x" + Integer.toHexString(user.getKey()) +
                                " support directive is null.");
                        continue;
                    }

                    if (supportDirective.contains(directiveName)) {

                        Log.d(TAG, "directive " + directive.getName()
                                + " send to remote module:" + module.getName()
                                + " uid 0x" + Integer.toHexString(user.getKey()));

                        IModule finalModule = module;
                        MMHandler.post(() -> finalModule.handleDirective(directive));
                        findRemoteModuleSupportDirective = true;
                    }
                } else {

                    // remote module is not alive,remove it.
                    Log.w(TAG, "remote module:" + module.getName() +
                            " in uid 0x" + Integer.toHexString(user.getKey()) +
                            " die.");
                    needClearDied = true;
                }
            }
        }

        if (needClearDied) clearDie();

        if (findRemoteModuleSupportDirective) return;

        // next notify local module.
        if (modules.containsKey(moduleName)) {
            Log.d(TAG, "local module find:" + moduleName);

            module = modules.get(moduleName);

            supportDirective = module.supportDirective();
            if (supportDirective.contains(directiveName)) {
                Log.d(TAG, "directive " + directive.getName()
                        + " send to local module:" + module.getName());
                module.handleDirective(directive);
                return;
            }
        }

        Log.w(TAG, "module:" + moduleName + " not registered.");
    }

    /**
     * remove died module
     */
    private void clearDie() {
        Iterator<Map.Entry<Integer, Map<ModuleName, IModule>>> iteratorUser;
        // remove died module.
        iteratorUser = remoteModules.entrySet().iterator();
        while (iteratorUser.hasNext()) {
            Map.Entry<Integer, Map<ModuleName, IModule>> user = iteratorUser.next();
            Iterator<Map.Entry<ModuleName, IModule>> moduleIterator;
            moduleIterator = user.getValue().entrySet().iterator();
            while (moduleIterator.hasNext()) {
                Map.Entry<ModuleName, IModule> module = moduleIterator.next();
                if (!module.getValue().asBinder().pingBinder()) {
                    moduleIterator.remove();
                    Log.d(TAG, "died module 0x" + module.getKey() + " in uid " +
                            Integer.toHexString(user.getKey()) + " be cleared.");
                }
            }
        }

        // remove empty user.
        iteratorUser = remoteModules.entrySet().iterator();
        while (iteratorUser.hasNext()) {
            Map.Entry<Integer, Map<ModuleName, IModule>> user = iteratorUser.next();
            if (user.getValue().isEmpty()) {
                iteratorUser.remove();
                Log.d(TAG, "uid: 0x" + Integer.toHexString(user.getKey()) +
                        " has no module registered will be clear.");
            }
        }
    }


    /**
     * add listener to module handle directive.
     *
     * @param listener
     */
    public final void addDirectiveListener(OnDirectiveListener listener) {
        MMHandler.post(() -> directiveListeners.add(listener));
    }

    /**
     * remove listener to module handle directive.
     *
     * @param listener
     */
    public final void removeDirectiveListener(OnDirectiveListener listener) {
        MMHandler.post(() -> directiveListeners.remove(listener));
    }

    /**
     * notify listener that module is ready to handle directive.
     * if one listener consume the directive, the last listener will
     * not receive notification.
     *
     * @param directive
     */
    protected final boolean notifyDirectiveListener(Directive directive) {
        for (OnDirectiveListener listener : directiveListeners
        ) {
            if (listener.onDirective(directive)) {
                return true;
            }
        }
        return false;
    }

    /**
     * notify <code> ModuleManager </> that module is ready to handle directive.
     *
     * @param directive
     * @return true is ModuleManager consume this directive,other listener will
     * not be notified.
     */
    protected final boolean notifyDirectiveManagerListener(Directive directive) {
        if (directiveManagerListener == null) {
            return false;
        }
        return directiveManagerListener.onDirective(directive);
    }

    /**
     * dump Module Manager State
     *
     * @param fd     raw file descriptor
     * @param writer writer
     * @param args   args
     */
    public void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        //CyclicBarrier barrier = new CyclicBarrier(1);

        dumpLatch = new CountDownLatch(2);

        for (String arg : args) {
            if (arg.equals("stop")) {
                boolean result = MMHandler.post(() -> {
                    throw new RuntimeException("test");
                });
                Log.d(TAG, "post stop:" + result);
                break;
            }
        }

        int size = args.length;
        for (int i = 0; i < size; i++) {
            if (args[i].equals("clear")) {
                MMHandler.post(() -> remoteModules.clear());
                break;
            }
        }

        writer.write("\n\nModuleManager State:\n");

        if (!MMHandler.post(() -> {
            // local module
            writer.write("\nLocal Module:\n");
            for (Map.Entry<ModuleName, IModule> entry :
                    modules.entrySet()
            ) {
                writer.write("ModuleName:" + entry.getKey() + "\n");
                for (DirectiveName directive :
                        modules.get(entry.getKey()).supportDirective()
                ) {
                    writer.write("\t" + directive + "\n");
                }
            }
            // this mayn't execute.
            dumpLatch.countDown();
        })) {
            dumpLatch.countDown();
        }


        if (!MMHandler.post(() -> {
            // remote module
            writer.write("\nRemote Module:\n");
            for (Map.Entry<Integer, Map<ModuleName, IModule>> user :
                    remoteModules.entrySet()
            ) {
                writer.write("UID:0x" + Integer.toHexString(user.getKey()) + "\n");
                for (Map.Entry<ModuleName, IModule> entry :
                        user.getValue().entrySet()
                ) {
                    writer.write("\tModuleName:" + entry.getKey() + "\n");
                    List<DirectiveName> directives =
                            entry.getValue().supportDirective();
                    if (directives == null) {
                        continue;
                    }
                    for (DirectiveName directive :
                            directives
                    ) {
                        writer.write("\t\t" + directive + "\n");
                    }
                }
            }
            // this mayn't execute.
            dumpLatch.countDown();
        })) {
            dumpLatch.countDown();
        }

        try {
            dumpLatch.await(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Log.d(TAG, "Dump Wait Error");
        }
    }
}
