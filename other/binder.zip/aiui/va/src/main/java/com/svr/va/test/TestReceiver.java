package com.svr.va.test;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

public class TestReceiver extends BroadcastReceiver {

    String TAG = "IntentPerformanceTest";
    StringBuilder buffer = new StringBuilder();
    @Override
    public void onReceive(Context context, Intent intent) {
        int data_order = intent.getIntExtra("data_order", -1);
        byte[] test_data = intent.getByteArrayExtra("test_data");

        buffer.append("onReceive: ");
        buffer.append(" order=");
        buffer.append(data_order);
        buffer.append(" size=");
        buffer.append(test_data.length);
        buffer.append(" time=");
        buffer.append(SystemClock.elapsedRealtime() / 1000);
        buffer.append(" mark=");
        buffer.append(test_data[0]);
        buffer.append(test_data[1]);
        buffer.append(test_data[2]);
        buffer.append(test_data[3]);

        Log.w(TAG, buffer.toString());
        buffer.delete(0, buffer.length() - 1);
    }
}
