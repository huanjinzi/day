package com.svr.va.test;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;

public class TestServiceStub extends Binder {

    String TAG = "IntentPerformanceTest";

    @Override
    protected boolean onTransact(int code,  Parcel data,  Parcel reply, int flags) throws RemoteException {
        switch (code) {
            case 111:
                data.enforceInterface("IntentPerformanceTest");
                Log.w(TAG, "onTransact:" + code);
                String message = data.readString();
                Log.w(TAG, "onTransact:RX=" + message + " code " + code);

                IBinder[] binders = new IBinder[1];
                data.readBinderArray(binders);

                IBinder binder = binders[0];

                if (binder.pingBinder()) {
                    Log.w(TAG, "ping success.");
                    Log.w(TAG, binder.getClass().getName());
                }
                reply.writeNoException();
                reply.writeString("hahaha.");
                return true;
        }
        return super.onTransact(code, data, reply, flags);
    }
}
