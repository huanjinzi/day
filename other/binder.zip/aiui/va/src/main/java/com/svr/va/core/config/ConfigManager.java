/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.config;

import com.svr.va.core.config.xunfei.AIUIConfig;

public class ConfigManager {

    private IConfig currentConfig = new AIUIConfig();
    private final static ConfigManager manager = new ConfigManager();

    public static void init() {
        manager.currentConfig.init();
    }

    public static void reset() {
        manager.currentConfig.reset();
    }

    public static ConfigManager getInstance() {
        return manager;
    }

    public static void wakeup() {
        manager.currentConfig.wakeup();
    }

    public static void startRecord() {
        manager.currentConfig.startRecord();
    }

    public static void stopRecord() {
        manager.currentConfig.stopRecord();
    }
}
