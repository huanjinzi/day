/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.svr.va.core.VAServiceInternal;
import com.svr.va.core.VAServiceStub;
import com.svr.va.core.config.ConfigManager;
import com.svr.va.util.Log;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public class VAService extends Service {

    private static final String TAG = "VAService";
    private IntentFilter screenFilter;

    {
        screenFilter = new IntentFilter();
        screenFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenFilter.addAction(Intent.ACTION_SCREEN_OFF);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate()");

        if (App.IOHandler.post(
                () -> {
                    ConfigManager.init();
                    ConfigManager.startRecord();
                })) {
            Log.d(TAG, "AIUI init posted.");
        } else {
            Log.e(TAG, "AIUI init not posted.");
        }
        registerReceiver(screenStateReceiver, screenFilter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "voice assistant service has started.");
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind():" + intent.getComponent());
        return VAServiceStub.getInstance();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy()");
        unregisterReceiver(screenStateReceiver);
        App.AIUI.destroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d(TAG, "onConfigurationChanged()");
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.d(TAG, "onLowMemory()");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.d(TAG, "onTrimMemory():level " + level);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "onUnbind():" + intent.getComponent());
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
        Log.d(TAG, "onRebind():" + intent.getComponent());
    }

    @Override
    protected void dump(FileDescriptor fd, PrintWriter writer, String[] args) {
        for (String arg : args) {
            Log.d(TAG, "arg:" + arg);
        }
        VAServiceInternal.INSTANCE.dump(fd, writer, args);
    }

    BroadcastReceiver screenStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case Intent.ACTION_SCREEN_ON:
                    Log.i(TAG, "ACTION_SCREEN_ON");
                    ConfigManager.startRecord();
                    break;
                case Intent.ACTION_SCREEN_OFF:
                    Log.i(TAG, "ACTION_SCREEN_OFF");
                    ConfigManager.stopRecord();
                    break;
            }
        }
    };
}
