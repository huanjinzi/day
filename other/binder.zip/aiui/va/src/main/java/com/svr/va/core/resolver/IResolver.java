/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver;

import com.svr.va.remote.directive.Directive;

public interface IResolver {

    /**
     * when sdk listener request this resolver,method onRequestDirective will be called.
     * @param params metadata sdk listener directly passed.
     */
    Directive onRequestDirective(Object ... params);

    /**
     * @return get resolver's name.
     */
    ResolverName getName();

}
