/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.localmodule;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.util.Log;
import com.svr.va.remote.module.ModuleName;
import com.svr.va.remote.module.Module;

import java.util.ArrayList;
import java.util.List;

public class DeviceControl extends Module {

    private final static String TAG = "DeviceControl";
    private static ModuleName name = new ModuleName("ISKYWORTH.IDeviceControl");

    private ArrayList supportDirective = new ArrayList(){
        {
            add(new DirectiveName("brightnessUp"));
            add(new DirectiveName("brightnessDown"));
        }
    };

    @Override
    public void handleDirective(Directive directive) {
        Log.d(TAG, "remote module directive:" +
                directive.getName());
    }

    @Override
    public List<DirectiveName> supportDirective() {
        return supportDirective;
    }

    @Override
    public ModuleName getName() {
        return name;
    }

}
