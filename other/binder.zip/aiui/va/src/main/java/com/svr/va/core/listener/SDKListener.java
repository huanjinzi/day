package com.svr.va.core.listener;

public class SDKListener {
    private final SDKName name;

    public SDKListener(SDKName name) {
        this.name = name;
    }

    public SDKName getName() {
        return name;
    }
}