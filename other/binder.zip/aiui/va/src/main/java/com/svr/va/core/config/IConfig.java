package com.svr.va.core.config;

public interface IConfig {

    void init();
    void reset();
    void wakeup();
    void startRecord();
    void stopRecord();
}
