/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver.xunfei;

import com.svr.va.remote.directive.Directive;
import com.svr.va.core.OnDirectiveListener;
import com.svr.va.core.resolver.IResolver;

import java.util.ArrayList;

/**
 * there is 5 type resolver:
 * iat
 * nlp
 * tpp
 * tts
 * itrans
 *
 * different service deal with different aiui server response.
 */
public abstract class XFResolver implements IResolver {

    /** 听写结果 */
    public static final String IAT = "iat";

    /** Nature Language Process */
    public static final String NLP = "nlp";

    /** 后处理服务结果 */
    public static final String TPP = "tpp";

    /** Text To Speech */
    public static final String TTS = "tts";

    /** 翻译结果*/
    public static final String ITRANS = "itrans";

    public static final String CTRL_DATA = "data";
    public static final String CTRL_PARAMS = "params";
    public static final String CTRL_PARAMS_SUBJECT = "sub";
    public static final String CTRL_CONTENT = "content";
    public static final String CTRL_CONTENT_ID = "cnt_id";
    public static final String CTRL_CONTENT_ENCODING = "dte";
    public static final String CTRL_CONTENT_FORMAT = "dtf";
    public static final String CTRL_CONTENT_TTS_CANCEL = "cancel";

    public static final String DATA_INTENT = "intent";
    public static final String DATA_TEXT = "text";
    public static final String DATA_INTENT_SERVICE = "service";
    public static final String DATA_INTENT_TEXT = "text";
    public static final String DATA_INTENT_RESPONSE_CODE = "rc";
    public static final String DATA_INTENT_SEMANTIC = "semantic";
    public static final String DATA_INTENT_SEMANTIC_INTENT = "intent";

    /** success */
    public static final int INTENT_RESPONSE_SUCCESS = 0;

    /** input error */
    public static final int INTENT_RESPONSE_INPUT_ERROR = 1;

    /** sdk internal error */
    public static final int INTENT_RESPONSE_INTERNAL_ERROR = 2;

    /** server error. */
    public static final int INTENT_RESPONSE_REQUEST_FAIL = 3;

    /** no scene to fit */
    public static final int INTENT_RESPONSE_UNKNOWN = 4;


    /** when dispatch directive to this service's module,directive listener will be notified.*/
    protected ArrayList<OnDirectiveListener> directiveListeners = new ArrayList<>();

    /** directive listeners access lock*/
    protected final Object directiveListenersLock = new Object();

    private OnDirectiveListener directiveManagerListener;



    @Override
    public Directive onRequestDirective(Object... params) {
        return null;
    }

    /**
     * add listener to module handle directive.
     * @param listener
     */
    public final void addDirectiveListener(OnDirectiveListener listener) {
        synchronized (directiveListenersLock) {
            directiveListeners.add(listener);
        }
    }

    /**
     * add listener to module handle directive.
     * @param listener
     */
    public final void addDirectiveManagerListener(OnDirectiveListener listener) {
        directiveManagerListener = listener;
    }

    /**
     * remove listener to module handle directive.
     * @param listener
     */
    public final void removeDirectiveListener(OnDirectiveListener listener) {
        synchronized (directiveListenersLock) {
            directiveListeners.add(listener);
        }
    }

    /**
     * notify listener that module is ready to handle directive.
     * if one listener consume the directive, the last listener will
     * not receive notification.
     * @param directive
     */
    protected final boolean notifyDirectiveListener(Directive directive) {
        synchronized (directiveListenersLock) {
            for (OnDirectiveListener listener:directiveListeners
                 ) {

                if (listener.onDirective(directive)) {
                    return true;
                }

            }
        }
        return false;
    }

    /**
     * notify <code> VAServiceInternal </> that module is ready to handle directive.
     * @param directive
     * @return true is VAServiceInternal consume this directive,other listener will
     * not be notified.
     */
    protected final boolean notifyDirectiveManagerListener(Directive directive) {
        if (directiveManagerListener == null) {
            return false;
        }
        return directiveManagerListener.onDirective(directive);
    }
}
