package com.svr.va.localmodule;

import com.svr.va.util.Log;
import com.svr.va.remote.directive.TTSDirective;
import com.svr.va.remote.module.TTSModule;

public class TTS extends TTSModule {

    String TAG = "TTS";
    @Override
    public void handleDirective(TTSDirective directive) {
        Log.d(TAG, directive.percent + ",sid=" + directive.sid);
    }
}
