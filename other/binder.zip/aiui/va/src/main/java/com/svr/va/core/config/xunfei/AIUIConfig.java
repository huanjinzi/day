/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.config.xunfei;

import android.Manifest;
import android.content.res.AssetManager;
import android.support.annotation.RequiresPermission;

import com.hz.checker.Checker;
import com.iflytek.aiui.AIUIAgent;
import com.iflytek.aiui.AIUIConstant;
import com.iflytek.aiui.AIUIMessage;
import com.iflytek.cloud.SpeechUtility;
import com.svr.va.App;
import com.svr.va.BuildConfig;
import com.svr.va.core.config.IConfig;
import com.svr.va.core.listener.SDKListenerManager;
import com.svr.va.core.listener.SDKName;
import com.svr.va.core.listener.xunfei.AIUIListener;
import com.svr.va.util.MessageBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class AIUIConfig implements IConfig {

    @RequiresPermission(allOf = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.WRITE_EXTERNAL_STORAGE })
    @Override
    public void init() {
        Map<String, String> ivwPa = new LinkedHashMap<>();
        ivwPa.put("engine_start", "ivw");
        ivwPa.put("delay_init", "0");
        ivwPa.put("appid", BuildConfig.AIUI_APP_ID);

        String ivwPaStr = MessageBuilder.formatParamString(ivwPa);
        SpeechUtility utility =  SpeechUtility.createUtility(App.get(), ivwPaStr);
        App.AIUI = AIUIAgent.createAgent(App.get(), getAIUIConfig(),
                (AIUIListener) SDKListenerManager.INSTANCE.getSDKListener(SDKName.XUNFEI));
    }

    public static int getState() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_GET_STATE);
        App.AIUI.sendMessage(builder.build());
        return 0;
    }

    public static void write() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_WRITE);

        App.AIUI.sendMessage(builder.build());
    }

    public static void stopWrite() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_STOP_WRITE);

        App.AIUI.sendMessage(builder.build());
    }

    @Override
    public void reset() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_RESET);
        App.AIUI.sendMessage(builder.build());
    }

    public static void start() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_START);

        App.AIUI.sendMessage(builder.build());
    }

    public static void stop() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_STOP);

        App.AIUI.sendMessage(builder.build());
    }

    @Override
    public void wakeup() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_WAKEUP);

        App.AIUI.sendMessage(builder.build());
    }

    public static void resetWakeup() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_RESET_WAKEUP);

        App.AIUI.sendMessage(builder.build());
    }

    public static void setParams() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_SET_PARAMS);

        App.AIUI.sendMessage(builder.build());
    }

    public static void sync() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_SYNC);

        App.AIUI.sendMessage(builder.build());
    }

    public static void resultValidationACK() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_RESULT_VALIDATION_ACK);

        App.AIUI.sendMessage(builder.build());
    }

    public static void cleanDialogHistory() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_CLEAN_DIALOG_HISTORY);

        App.AIUI.sendMessage(builder.build());
    }

    @Override
    public void startRecord() {
        MessageBuilder recordBu = new MessageBuilder();
        recordBu.type(AIUIConstant.CMD_START_RECORD);

        Map<String, String> recordPa = new HashMap<>();
        recordPa.put("sample_rate", "16000");
        recordPa.put("data_type", "audio");
        recordPa.put("pers_param", "{\"uid\":\"\"}");
        recordPa.put("tag", "audio-tag");

        recordBu.param(recordPa);
        AIUIMessage record = recordBu.build();
        App.AIUI.sendMessage(record);
    }

    @Override
    public void stopRecord() {
        MessageBuilder builder = new MessageBuilder();

        builder.type(AIUIConstant.CMD_STOP_RECORD);

        Map<String, String> map = new HashMap<>();
        map.put("sample_rate", "16000");
        map.put("data_type", "audio");

        builder.param(map);

        App.AIUI.sendMessage(builder.build());
    }

    public static void querySyncStatus() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_QUERY_SYNC_STATUS);

        App.AIUI.sendMessage(builder.build());
    }

    public static void requestTTS() {
        MessageBuilder builder = new MessageBuilder();
        builder.type(AIUIConstant.CMD_TTS);

        App.AIUI.sendMessage(builder.build());
    }

    public static String getAIUIConfig() {
        AssetManager assetManager = App.get().getResources().getAssets();

        byte[] config = null;
        try {
            InputStream ins =
                    assetManager.open("aiui/config.json");
            config = new byte[ins.available()];
            ins.read(config);
            ins.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        Checker.check(config);

        String aiuiConfig = new String(config);

        try {
            JSONObject configJ = new JSONObject(aiuiConfig);

            if (configJ.has("login")) {
                return aiuiConfig;
            }

            JSONObject loginJ = new JSONObject();
            loginJ.put("appid", BuildConfig.AIUI_APP_ID);
            loginJ.put("key", BuildConfig.AIUI_KEY);

            configJ.put("login", loginJ);
            aiuiConfig = configJ.toString();

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return aiuiConfig;
    }
}
