package com.svr.va;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import com.svr.va.util.Log;

import java.util.Objects;

public class ServiceStartReceiver extends BroadcastReceiver {
    private String TAG = "ServiceStartReceiver";
    private Intent serviceIntent;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "start va service " + intent.getAction());
        if (serviceIntent == null) {
            serviceIntent = new Intent();
            ComponentName componentName = new ComponentName(BuildConfig.APPLICATION_ID,
                    VAService.class.getName());
            serviceIntent.setComponent(componentName);
        }

        switch (Objects.requireNonNull(intent.getAction())) {
            case Intent.ACTION_BOOT_COMPLETED:
            case Intent.ACTION_POWER_CONNECTED:
            case Intent.ACTION_BATTERY_CHANGED:
                context.startService(serviceIntent);
                break;
        }
    }
}
