/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.core.resolver.svr;

import com.svr.va.core.resolver.IResolver;
import com.svr.va.core.resolver.ResolverName;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.WakeupDirective;

public class WakeupResolver implements IResolver {
    private static final WakeupDirective WAKEUP = new WakeupDirective();
    @Override
    public Directive onRequestDirective(Object... params) {
        return WAKEUP;
    }

    @Override
    public ResolverName getName() {
        return ResolverName.WAKEUP;
    }
}
