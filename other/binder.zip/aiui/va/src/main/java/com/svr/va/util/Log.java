/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.util;

public final class Log {

    private static String pre = "va_";
    private static final boolean DEBUG = false;

    public static void i(String tag, String message) {
        android.util.Log.i(pre + tag, message);
    }

    public static void e(String tag, String message, Throwable tr) {
        android.util.Log.e(pre + tag, message, tr);
    }

    public static void w(String tag, String message) {
        if (!DEBUG) return;
        android.util.Log.w(pre + tag, message);
    }

    public static void d(String tag, String message) {
        if (!DEBUG) return;
        android.util.Log.d(pre + tag, message);
    }

    public static void e(String tag, String message) {
        android.util.Log.e(pre + tag, message);
    }
}
