/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va;

import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.res.Configuration;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import com.hz.checker.Checker;
import com.iflytek.aiui.AIUIAgent;
import com.svr.va.util.Log;
import com.svr.va.core.annotation.Singleton;

@Singleton
public final class App extends Application {

    public static final String TAG = "App";
    private static App app;
    public static Handler IOHandler;
    public static Handler UIHandler;
    public static AIUIAgent AIUI;
    private HandlerThread IOThread;

    private Looper looper;

    public App() {
        super();

        if (app == null) {
            app = this; // must singleton.
        }
    }

    private Thread.UncaughtExceptionHandler IOThreadExceptionHandler =
            new Thread.UncaughtExceptionHandler() {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
            Log.e(TAG, "io thread died,restart.");
            looper.quitSafely();
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            init();
        }
    };

    private void init() {
        IOThread = new HandlerThread("IOThread");
        IOThread.setUncaughtExceptionHandler(IOThreadExceptionHandler);
        IOThread.start();
        looper = IOThread.getLooper();
        IOHandler = new Handler(looper);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.w(TAG, "App.onCreate()");
        UIHandler = new Handler();
        init();
    }

    public static App get() {
        Checker.check(app);
        return app;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Log.i(TAG, "onLowMemory");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.i(TAG, "onTrimMemory");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.i(TAG, "onConfigurationChanged");
    }

    @Override
    public void registerComponentCallbacks(ComponentCallbacks callback) {
        super.registerComponentCallbacks(callback);
    }

    @Override
    public void unregisterComponentCallbacks(ComponentCallbacks callback) {
        super.unregisterComponentCallbacks(callback);
    }

    @Override
    public void registerActivityLifecycleCallbacks(ActivityLifecycleCallbacks callback) {
        super.registerActivityLifecycleCallbacks(callback);
    }

    @Override
    public void unregisterActivityLifecycleCallbacks(ActivityLifecycleCallbacks callback) {
        super.unregisterActivityLifecycleCallbacks(callback);
    }

    @Override
    public void registerOnProvideAssistDataListener(OnProvideAssistDataListener callback) {
        super.registerOnProvideAssistDataListener(callback);
    }

    @Override
    public void unregisterOnProvideAssistDataListener(OnProvideAssistDataListener callback) {
        super.unregisterOnProvideAssistDataListener(callback);
    }

}
