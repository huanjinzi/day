package com.svr.va.core;

import org.junit.Test;

public class PayloadTest {

    @Test
    public void nameSpace(){

        //Assert.assertNotNull(BrightnessUpPayload.getNameSpace());
    }

}