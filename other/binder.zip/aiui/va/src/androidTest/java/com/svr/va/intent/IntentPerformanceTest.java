package com.svr.va.intent;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.support.test.InstrumentationRegistry;
import android.util.Log;

import com.svr.va.BuildConfig;
import com.svr.va.test.TestService;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

public class IntentPerformanceTest extends Binder {
    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {

        String message = data.readString();
        Log.d(TAG, "onTransact:RX=" + message);
        return super.onTransact(code, data, reply, flags);
    }

    private static final String TAG = "IntentPerformanceTest";
    private TestService service;
    private Context appContext = InstrumentationRegistry.getTargetContext();
    private Intent bindIntent;
    private IBinder testService;

    private Binder mBinder = new Binder(){
        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case 112:
                    Log.w(TAG, "code 112.");
                    return true;
            }
            return super.onTransact(code, data, reply, flags);
        }
    };


    @Before
    public void bindService() {
        ComponentName componentName = new ComponentName(BuildConfig.APPLICATION_ID, TestService.class.getName());
        bindIntent = new Intent();
        bindIntent.setComponent(componentName);
    }

    @Test
    public void intent() throws Exception {
        boolean result = appContext.bindService(bindIntent, new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                testService = service;
                Log.w(TAG, "onServiceConnected");

                Parcel data = Parcel.obtain();
                data.writeInterfaceToken("IntentPerformanceTest");
                data.writeString("i am IntentPerformanceTest");
                data.writeBinderArray(new Binder[]{mBinder});

                Parcel reply = Parcel.obtain();
                try {
                    testService.transact(111,data,reply,0);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }

                reply.readException();
                Log.w(TAG, "reply:" + reply.readString());

                reply.recycle();
                data.recycle();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }

            @Override
            public void onNullBinding(ComponentName name) {
                System.out.println("onNullBinding:" + name);
                Log.d(TAG, "onNullBinding:" + name);
            }
        }, Context.BIND_AUTO_CREATE);

        System.out.println("result:" + result);
        Log.d(TAG, "result:" + result);
    }

    @Test
    public void intentPerformance() throws Exception {

        byte[] test_data = new byte[500 * 1024];
        Intent intent = new Intent();

        intent.setAction("com.svr.aiui.HJZ");
        intent.putExtra("test_data", test_data);

        for (int order = 0; order < 100; order++) {
            intent.putExtra("data_order", order);
            Log.d(TAG, "send test data order=" + order);
            Arrays.fill(test_data, (byte) 12);
            //testDataInit(test_data);
            test_data[0] = 1;
            test_data[1] = 5;
            test_data[2] = 7;
            test_data[3] = 3;
            //intent.
            appContext.sendBroadcast(intent);
            //appContext.sendOrderedBroadcast(intent);

        }

        Thread.sleep(10 * 1000);

    }

    private void testDataInit(byte[] data) {
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) System.currentTimeMillis();
        }
    }
}
