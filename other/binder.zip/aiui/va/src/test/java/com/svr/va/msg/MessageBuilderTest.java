package com.svr.va.msg;

import com.svr.va.BuildConfig;
import com.svr.va.util.MessageBuilder;

import org.junit.Assert;
import org.junit.Test;

import java.util.LinkedHashMap;
import java.util.Map;

public class MessageBuilderTest {
    @Test
    public void buildParam() throws Exception {

        String expected = "engine_start=ivw,delay_init=0,appid=" + BuildConfig.AIUI_APP_ID;
        Map<String,String> paramMap = new LinkedHashMap<>();
        paramMap.put("engine_start", "ivw");
        paramMap.put("delay_init", "0");
        paramMap.put("appid", BuildConfig.AIUI_APP_ID);

        String param = MessageBuilder.formatParamString(paramMap);
        Assert.assertEquals(expected, param);
    }

}