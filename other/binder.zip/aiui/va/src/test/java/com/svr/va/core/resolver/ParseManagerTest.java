package com.svr.va.core.resolver;

import com.svr.va.core.VAServiceInternal;
import com.svr.va.core.resolver.xunfei.XFResolver;
import com.svr.va.core.resolver.xunfei.NLPResolver;

import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;

public class ParseManagerTest {

    private final VAServiceInternal serviceManager = VAServiceInternal.getInstance();
    @Before
    public void startService() throws Exception {
        System.out.println("startService");
        XFResolver nlp =  new NLPResolver();
        serviceManager.registerService(nlp);
    }

    @Test
    public void handleDirectiveTest() throws Exception {
        ClassLoader loader = ClassLoader.getSystemClassLoader();
        InputStream in = loader.getResourceAsStream("info.json");


        byte[] buffer = new byte[in.available()];
        in.read(buffer);
        String info = new String(buffer);
        //System.out.println(info);
        in.close();

        in = loader.getResourceAsStream("data.json");
        buffer = new byte[in.available()];
        in.read(buffer);
        String data = new String(buffer);
        in.close();
        //System.out.println(data);


    }
}