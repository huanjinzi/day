/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.directive;

import android.os.Parcel;
import android.os.Parcelable;

import com.svr.va.remote.module.ModuleName;

public class Directive implements Parcelable {

    private final ModuleName moduleName;

    private final DirectiveName directiveName;

    protected Directive(Parcel in) {
        moduleName = in.readParcelable(ModuleName.class.getClassLoader());
        directiveName = in.readParcelable(DirectiveName.class.getClassLoader());
    }

    public static final Creator<Directive> CREATOR = new Creator<Directive>() {
        @Override
        public Directive createFromParcel(Parcel in) {
            return new Directive(in);
        }

        @Override
        public Directive[] newArray(int size) {
            return new Directive[size];
        }
    };

    public ModuleName getModuleName() {
        return moduleName;
    }

    public DirectiveName getName() {
        return directiveName;
    }

    public Directive(DirectiveName directiveName, ModuleName moduleName) {
        this.directiveName = directiveName;
        this.moduleName = moduleName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(moduleName, flags);
        dest.writeParcelable(directiveName, flags);
    }
}
