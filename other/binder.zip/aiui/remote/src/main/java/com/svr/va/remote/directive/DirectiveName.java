/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.directive;

import android.os.Parcel;

import com.svr.va.remote.InterfaceName;

public class DirectiveName extends InterfaceName {
    public DirectiveName(String fullName) {
        super(fullName);
    }

    public DirectiveName(Parcel source) {
        super(source);
        // self:no
    }
    public static final Creator<DirectiveName> CREATOR = new Creator<DirectiveName>() {
        @Override
        public DirectiveName createFromParcel(Parcel source) {
            return new DirectiveName(source);
        }

        @Override
        public DirectiveName[] newArray(int size) {
            return new DirectiveName[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        // self:no
    }

    public static final DirectiveName TTS = new DirectiveName("tts");
    public static final DirectiveName IAT = new DirectiveName("iat");
    public static final DirectiveName WAKEUP = new DirectiveName("wakeup");
}
