/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/**
 * Sample Code:
 * <code>
 * IVAService mService;
 * ServiceConnection = serviceListener = new ServiceConnection() {
 *      @Override
 *      public void onServiceConnected(ComponentName name, IBinder service) {
 *          mService = IVAService.Stub.asInterface(service);
 *          // IVAService.Stub.Proxy
 *          mService.registerModule(new TestModule());
 *      }
 *
 *      @Override
 *      public void onServiceDisconnected(ComponentName name) {
 *
 *      }
 * }
 *
 * Intent serviceIntent = new Intent();
 * ComponentName serviceName = new ComponentName(IVAService.PACKAGE,IVAService);
 * serviceIntent.setComponent(serviceName);
 *
 * bindService(serviceIntent,serviceListener,BIND_AUTO_CREATE);
 *
 * </code>
 */
public interface IVAService extends IInterface {

    String PACKAGE = "com.svr.va";
    String CLASS = "com.svr.va.VAService";

    /**
     * register module,when service dispatch directive,corresponding module's
     * <code> handleDirective()</> method will be called.
     * @param module module added to service.
     * */
    void registerModule(IModule module);

    /**
     * this method is thread safe.
     * @param module the module removed from this service.
     */
    void unregisterModule(IModule module);

    void updateSDKConfig(SDKConfig config);

    void wakeup();

    abstract class Stub extends Binder implements IVAService {
        public static final String DESCRIPTOR = "IVAService";

        public static final int TRANSACTION_registerModule = IBinder.FIRST_CALL_TRANSACTION;
        public static final int TRANSACTION_unregisterModule = IBinder.FIRST_CALL_TRANSACTION + 1;
        public static final int TRANSACTION_updateSDKConfig = IBinder.FIRST_CALL_TRANSACTION + 2;
        public static final int TRANSACTION_wake = IBinder.FIRST_CALL_TRANSACTION + 3;

        public Stub() {
            this.attachInterface(this, DESCRIPTOR);
        }

        public static IVAService asInterface(IBinder remote) {
            if (remote == null) {
                return null;
            }
            IInterface port = remote.queryLocalInterface(DESCRIPTOR);
            if (port instanceof IVAService) {
                return (IVAService) port;
            }
            return new Proxy(remote);
        }

        @Override
        public IBinder asBinder() {
            return this;
        }

        private static final class Proxy implements IVAService {
            private static final String TAG = "va_IVAService.Proxy";
            private final IBinder remote;
            private IBinder[] binders = new IBinder[1];

            private Proxy(IBinder remote) {
                this.remote = remote;
            }

            @Override
            public IBinder asBinder() {
                return remote;
            }

            @Override
            public void registerModule(IModule module) {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);
                    // IModule.Stub extends Binder
                    binders[0] = module.asBinder();
                    data.writeBinderArray(binders);
                    remote.transact(TRANSACTION_registerModule, data, reply, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    data.recycle();
                    reply.recycle();
                }
            }

            @Override
            public void unregisterModule(IModule module) {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);

                    binders[0] = module.asBinder();
                    data.writeBinderArray(binders);
                    remote.transact(TRANSACTION_unregisterModule, data, reply, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    data.recycle();
                    reply.recycle();
                }
            }

            @Override
            public void updateSDKConfig(SDKConfig config) {

            }

            @Override
            public void wakeup() {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);
                    remote.transact(TRANSACTION_wake, data, reply, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    data.recycle();
                    reply.recycle();
                }
            }
        }
    }
}
