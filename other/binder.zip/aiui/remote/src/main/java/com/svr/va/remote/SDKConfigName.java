package com.svr.va.remote;

public class SDKConfigName extends InterfaceName {
    public SDKConfigName(String fullName) {
        super(fullName);
    }
}
