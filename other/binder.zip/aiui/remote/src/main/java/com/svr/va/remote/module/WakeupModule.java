/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.module;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.directive.WakeupDirective;

import java.util.ArrayList;
import java.util.List;

public abstract class WakeupModule extends Module {
    private final List support = new ArrayList(){{
        add(DirectiveName.WAKEUP);
    }};

    @Override
    public void handleDirective(Directive directive) {
        if (directive.getName().equals(DirectiveName.WAKEUP)) {
            handleDirective((WakeupDirective) directive);
        }
    }

    public abstract void handleDirective(WakeupDirective directive);

    @Override
    public final List<DirectiveName> supportDirective() {
        return support;
    }

    @Override
    public final ModuleName getName() {
        return ModuleName.WAKEUP;
    }

}
