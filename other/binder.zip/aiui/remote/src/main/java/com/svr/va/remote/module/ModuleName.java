/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.module;

import android.os.Parcel;

import com.svr.va.remote.InterfaceName;

public final class ModuleName extends InterfaceName {
    public ModuleName(String fullName) {
        super(fullName);
    }

    public static final Creator<ModuleName> CREATOR = new Creator<ModuleName>() {
        @Override
        public ModuleName createFromParcel(Parcel source) {
            return new ModuleName(source);
        }

        @Override
        public ModuleName[] newArray(int size) {
            return new ModuleName[size];
        }
    };

    public ModuleName(Parcel source) {
        super(source);
        // self
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        // self
    }

    public static final ModuleName TTS = new ModuleName("tts");
    public static final ModuleName IAT = new ModuleName("iat");
    public static final ModuleName WAKEUP = new ModuleName("wakeup");

}
