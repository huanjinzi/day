/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.directive;

import android.os.Parcel;

import com.svr.va.remote.module.ModuleName;

public class WakeupDirective extends Directive {
    protected WakeupDirective(Parcel in) {
        super(in);
    }

    public WakeupDirective() {
        super(DirectiveName.WAKEUP, ModuleName.WAKEUP);
    }

    public static final Creator<WakeupDirective> CREATOR = new Creator<WakeupDirective>() {
        @Override
        public WakeupDirective createFromParcel(Parcel source) {
            return new WakeupDirective(source);
        }

        @Override
        public WakeupDirective[] newArray(int size) {
            return new WakeupDirective[size];
        }
    };
}
