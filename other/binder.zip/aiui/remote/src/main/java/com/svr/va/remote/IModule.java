/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.module.ModuleName;

import java.util.Arrays;
import java.util.List;

public interface IModule extends IInterface {

    /**
     * when service dispatch directive to module,module can interact with destination device.
     *
     * @param directive contains payload and extra information to tell module what to do.
     */
    void handleDirective(Directive directive);

    /**
     * when service dispatch directive to module,service will query what payload
     * the module support,other module can't receive it.this means
     * handleDirective  will not be called.
     *
     * @return module support payloads.
     */
    List<DirectiveName> supportDirective();

    /**
     * @return module's name.
     */
    ModuleName getName();

    int getUid();

    void setUid(int uid);

    int LOCAL_UID = -1;
    abstract class Stub extends Binder implements IModule {
        public static final String DESCRIPTOR = "IModule";

        public static final int TRANSACTION_handleDirective = IBinder.FIRST_CALL_TRANSACTION;
        public static final int TRANSACTION_supportDirective = IBinder.FIRST_CALL_TRANSACTION + 1;
        public static final int TRANSACTION_getName = IBinder.FIRST_CALL_TRANSACTION + 2;


        public Stub() {
            this.attachInterface(this, DESCRIPTOR);
        }

        public static IModule asInterface(IBinder remote) {

            if (remote == null) {
                return null;
            }
            IInterface port = remote.queryLocalInterface(DESCRIPTOR);
            if (port instanceof IModule) {
                return (IModule) port;
            }
            return new Proxy(remote);
        }

        @Override
        public final int getUid() {
            return LOCAL_UID;
        }

        @Override
        public final void setUid(int uid) {

        }

        @Override
        public final IBinder asBinder() {
            return this;
        }

        private static final class Proxy  implements IModule {
            private final IBinder remote;
            private int uid;

            private Proxy(IBinder remote) {
                this.remote = remote;
            }

            @Override
            public final IBinder asBinder() {
                return remote;
            }

            @Override
            public final void handleDirective(Directive directive) {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);
                    data.writeParcelable(directive, 0);
                    remote.transact(TRANSACTION_handleDirective, data, reply, 0);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    data.recycle();
                    reply.recycle();
                }

            }

            @Override
            public final List<DirectiveName> supportDirective() {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);
                    remote.transact(TRANSACTION_supportDirective, data, reply, 0);
                    ClassLoader loader = com.svr.va.remote.InterfaceName.class.getClassLoader();

                    Parcelable[] parcelable;
                    parcelable = reply.readParcelableArray(loader);

                    DirectiveName[] directives;
                    directives = Arrays.copyOf(parcelable, parcelable.length, DirectiveName[].class);
                    return Arrays.asList(directives);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    data.recycle();
                    reply.recycle();
                }
                return null;
            }

            @Override
            public final com.svr.va.remote.module.ModuleName getName() {
                Parcel data = Parcel.obtain();
                Parcel reply = Parcel.obtain();

                try {
                    data.writeInterfaceToken(DESCRIPTOR);
                    remote.transact(TRANSACTION_getName, data, reply, 0);
                    ClassLoader loader = com.svr.va.remote.InterfaceName.class.getClassLoader();
                    InterfaceName module;
                    module = reply.readParcelable(loader);
                    return (com.svr.va.remote.module.ModuleName) module;
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    data.recycle();
                    reply.recycle();
                }
                return null;
            }

            @Override
            public final int getUid() {
                return uid;
            }

            @Override
            public final void setUid(int uid) {
                this.uid = uid;
            }

            @Override
            public final String toString() {
                ModuleName name = getName();
                if (name != null) {
                    return name.toString();
                }
                return "null";
            }
        }
    }
}
