package com.svr.va.remote;

public class SDKConfig {
    private final SDKConfigName name;

    public SDKConfig(SDKConfigName name) {
        this.name = name;
    }

    public SDKConfigName getName() {
        return name;
    }
}
