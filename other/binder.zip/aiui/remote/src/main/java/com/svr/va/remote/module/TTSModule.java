/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.module;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.directive.TTSDirective;

import java.util.ArrayList;
import java.util.List;

public abstract class TTSModule extends Module {

    private static final List support = new ArrayList(){
        {
            add(com.svr.va.remote.directive.DirectiveName.TTS);
        }
    };

    @Override
    public final void handleDirective(Directive directive) {
        if (directive.getName().equals(ModuleName.TTS)) {
            handleDirective((com.svr.va.remote.directive.TTSDirective) directive);
        }
    }

    public abstract void handleDirective(TTSDirective directive);


    @Override
    public final List<DirectiveName> supportDirective() {
        return support;
    }


    @Override
    public final ModuleName getName() {
        return ModuleName.TTS;
    }
}
