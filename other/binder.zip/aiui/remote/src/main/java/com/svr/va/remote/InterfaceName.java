/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote;

import android.os.Parcel;
import android.os.Parcelable;

public class InterfaceName implements Parcelable {
    private  final String fullName;

    public InterfaceName(String  fullName){
        this.fullName = fullName;
    }

    protected InterfaceName(Parcel in) {
        fullName = in.readString();
    }

    public static final Creator<InterfaceName> CREATOR = new Creator<InterfaceName>() {
        @Override
        public InterfaceName createFromParcel(Parcel in) {
            return new InterfaceName(in);
        }

        @Override
        public InterfaceName[] newArray(int size) {
            return new InterfaceName[size];
        }
    };

    @Override
    public final int hashCode() {
        return fullName.hashCode();
    }

    @Override
    public String toString() {
        return fullName;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof InterfaceName) {
            InterfaceName interfaceName = (InterfaceName) obj;
            return interfaceName.toString().equals(toString());
        }
        return false;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fullName);
    }
}
