/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.directive;

import android.os.Parcel;
import android.os.Parcelable;

import com.svr.va.remote.module.ModuleName;

public class TTSDirective extends Directive {
    private TTSDirective(Parcel in) {
        super(in);
        int size = in.readInt();
        audio = new byte[size];
        in.readByteArray(audio);
        sid = in.readString();
        percent = in.readInt();

        int cancel = in.readInt();
        this.cancel = cancel == 1;

        rate = in.readInt();
        bit = in.readInt();

        text = in.readString();
        state = in.readInt();
    }

    public TTSDirective() {
        super(DirectiveName.TTS, ModuleName.TTS);
    }

    /** audio data. */
    public byte[] audio;

    /** sound id */
    public String sid;

    /** composite progress */
    public int percent;

    /** is cancel */
    public boolean cancel;

    /** bit rate.*/
    public int rate;

    /** bits */
    public int bit;

    /** text*/
    public String text;

    /** state 0 1 2 */
    public int state;

    public static final Parcelable.Creator<TTSDirective> CREATOR = new Parcelable.Creator<TTSDirective>() {
        @Override
        public TTSDirective createFromParcel(Parcel source) {
            return new TTSDirective(source);
        }

        @Override
        public TTSDirective[] newArray(int size) {
            return new TTSDirective[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);

        dest.writeInt(audio.length);
        dest.writeByteArray(audio);
        dest.writeString(sid);
        dest.writeInt(percent);

        int cancel = this.cancel ? 1 : 0;
        dest.writeInt(cancel);
        dest.writeInt(rate);
        dest.writeInt(bit);
        dest.writeString(text);
        dest.writeInt(state);
    }
}
