/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.directive;

import android.os.Parcel;
import android.os.Parcelable;

import com.svr.va.remote.module.ModuleName;

public class IATDirective extends Directive {
    private IATDirective(Parcel in) {
        super(in);
        text = in.readString();
        int last = in.readInt();
        this.last = last == 1;
    }

    public IATDirective() {
        super(DirectiveName.IAT, ModuleName.IAT);
    }

    public  String text;
    public boolean last;

    public static final Parcelable.Creator<IATDirective> CREATOR = new Parcelable.Creator<IATDirective>() {
        @Override
        public IATDirective createFromParcel(Parcel source) {
            return new IATDirective(source);
        }

        @Override
        public IATDirective[] newArray(int size) {
            return new IATDirective[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(text);

        int last = this.last ? 1 : 0;
        dest.writeInt(last);
    }
}
