/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.remote.module;

import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

import com.svr.va.remote.IModule;
import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class Module extends IModule.Stub {

    @Override
    protected final boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        switch (code) {
            case INTERFACE_TRANSACTION:
                reply.writeString(Stub.DESCRIPTOR);
                return true;
            case Stub.TRANSACTION_getName:
                data.enforceInterface(Stub.DESCRIPTOR);
                reply.writeParcelable(getName(),0);
                return true;
            case Stub.TRANSACTION_supportDirective:
                data.enforceInterface(Stub.DESCRIPTOR);
                reply.writeParcelableArray(supportDirective().toArray(new DirectiveName[]{}),0);
                return true;
            case Stub.TRANSACTION_handleDirective:
                data.enforceInterface(Stub.DESCRIPTOR);
                Directive directive;
                directive = data.readParcelable(Directive.class.getClassLoader());
                handleDirective(directive);
                return true;
        }
        return super.onTransact(code, data, reply, flags);
    }

    /**
     * for hash map.
     * @param obj compare object.
     * @return true is equal.
     */
    @Override
    public final boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj instanceof Module) {
            Module module = (Module) obj;
            return module.getName().equals(getName());
        }
        return false;
    }

    /**
     * for hash map.
     */
    @Override
    public final int hashCode() {
        return getName().hashCode();
    }

    @Override
    public final void attachInterface(IInterface owner, String descriptor) {
        super.attachInterface(owner, descriptor);
    }

    @Override
    public final String getInterfaceDescriptor() {
        return super.getInterfaceDescriptor();
    }

    @Override
    public final boolean pingBinder() {
        return super.pingBinder();
    }

    @Override
    public final boolean isBinderAlive() {
        return super.isBinderAlive();
    }

    @Override
    public final IInterface queryLocalInterface(String descriptor) {
        return super.queryLocalInterface(descriptor);
    }

    @Override
    public final void dump(FileDescriptor fd, String[] args) {
        super.dump(fd, args);
    }

    @Override
    public final void dumpAsync(FileDescriptor fd, String[] args) {
        super.dumpAsync(fd, args);
    }

    @Override
    protected final void dump(FileDescriptor fd, PrintWriter fout,String[] args) {
        super.dump(fd, fout, args);
    }

    @Override
    public final void linkToDeath(DeathRecipient recipient, int flags) {
        super.linkToDeath(recipient, flags);
    }

    @Override
    public final boolean unlinkToDeath(DeathRecipient recipient, int flags) {
        return super.unlinkToDeath(recipient, flags);
    }
}
