package com.svr.va.remote;

import android.os.Parcel;
import android.os.Parcelable;

import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.module.ModuleName;

public class ControlDirective extends Directive {

    public String test = "3233313144";

    public ControlDirective(Parcel in) {
        super(in);
        test = in.readString();
    }

    public ControlDirective(DirectiveName directiveName, ModuleName moduleName) {
        super(directiveName, moduleName);
    }

    public static final Parcelable.Creator<ControlDirective> CREATOR = new Parcelable.Creator<ControlDirective>() {
        @Override
        public ControlDirective createFromParcel(Parcel source) {
            return new ControlDirective(source);
        }

        @Override
        public ControlDirective[] newArray(int size) {
            return new ControlDirective[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(test);
    }
}
