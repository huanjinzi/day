package com.svr.va.demo;

import android.util.Log;

import com.svr.va.remote.directive.WakeupDirective;
import com.svr.va.remote.module.WakeupModule;

public class Wakeup extends WakeupModule {
    private String TAG = "va_WakeupModule";
    @Override
    public void handleDirective(WakeupDirective directive) {
        Log.w(TAG, "on wakeup...");
    }
}
