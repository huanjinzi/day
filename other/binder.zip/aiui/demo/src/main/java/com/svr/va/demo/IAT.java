package com.svr.va.demo;

import android.util.Log;

import com.svr.va.remote.directive.IATDirective;
import com.svr.va.remote.module.IATModule;

public class IAT extends IATModule {

    String TAG = "va_IATModule";
    private IATListener listener;
    @Override
    public void handleDirective(IATDirective directive) {
        Log.d(TAG, "iat:" + directive.text + " " + directive.last);
        if (listener != null) {
            listener.onIAT(directive.text, directive.last);
        }
    }

    public void setIAT(IATListener listener) {
        this.listener = listener;
    }

    interface IATListener {
        void onIAT(String text, boolean end);
    }
}
