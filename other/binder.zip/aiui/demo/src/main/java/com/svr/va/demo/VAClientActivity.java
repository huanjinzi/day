package com.svr.va.demo;

import android.Manifest;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresPermission;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.svr.va.remote.IVAService;
import com.svr.va.remote.directive.TTSDirective;

import java.util.ArrayList;
import java.util.List;

public class VAClientActivity extends AppCompatActivity implements IAT.IATListener, TTS.TTSListener {

    String TAG = "va_VAClientActivity";
    private Button register;
    private Button unregister;
    private RelativeLayout container;
    private TextView text;
    private TextView ttsText;

    private IVAService mService;
    private DeviceControl mDeviceControl = new DeviceControl();
    private IAT iat = new IAT();
    private TTS tts = new TTS();
    private Wakeup wakeup = new Wakeup();
    private Intent serviceIntent;
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.i(TAG, "onServiceConnected");
            mService = IVAService.Stub.asInterface(service);
            // IVAService.Stub.Proxy
            if (pendingRegisterEvent) {
                pendingRegisterEvent = false;// consume
                UIHandler.post(() -> register(null));
            }

            if (pendingUnregisterEvent) {
                pendingUnregisterEvent = false;// consume
                UIHandler.post(() -> unregister(null));
            }


            Log.d(TAG, "pendingWakeupEvent:" + pendingWakeupEvent);
            if (pendingWakeupEvent) {
                pendingWakeupEvent = false;
                UIHandler.postDelayed(() -> wakeup(null),800);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "onServiceDisconnected");
            //mService = null;
            pendingUnregisterEvent = false;// consume
            pendingRegisterEvent = false;// consume
            pendingWakeupEvent = false;
        }

        @Override
        public void onBindingDied(ComponentName name) {
            Log.w(TAG, "onBindingDied");
            showTip("Service Die");
            pendingUnregisterEvent = false;// consume
            pendingRegisterEvent = false;// consume
            pendingWakeupEvent = false;
        }
    };

    private DeviceControl.BrightnessListener brightnessListener = new DeviceControl.BrightnessListener() {
        @Override
        public void onBrightnessUp() {
            int current = getBrightness();

            int dest = current + 55;

            if (dest > 255) {
                dest = 255;
            }

            Log.d(TAG, String.format("onBrightnessUp current=%d，dest=%d", current, dest));
            saveBrightness(dest);
        }

        @Override
        public void onBrightnessDown() {
            int current = getBrightness();

            int dest;
            if (current < 35) {
                dest = 0;
            } else {
                dest = current - 35;
            }
            Log.d(TAG, String.format("onBrightnessDown current=%d,dest=%d", current, dest));
            saveBrightness(dest);
        }
    };

    @RequiresPermission(value = Manifest.permission.WRITE_SETTINGS)
    private void saveBrightness(int brightness) {
        checkPermission();
        if (!checkPermissionResult) {
            Log.w(TAG, "no WRITE_SETTINGS permission.");
            return;
        }
        if (brightness < 0 || brightness > 255) {
            brightness = 127;
        }
        setScreenManualMode();
        ContentResolver contentResolver = getContentResolver();
        Settings.System.putInt(contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, brightness);
    }

    @RequiresPermission(value = Manifest.permission.WRITE_SETTINGS)
    public void setScreenManualMode() {
        checkPermission();
        if (!checkPermissionResult) {
            Log.w(TAG, "no WRITE_SETTINGS permission.");
            return;
        }
        ContentResolver contentResolver = getContentResolver();
        try {
            int mode = Settings.System.getInt(contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE);
            if (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            }
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
    }

    private int getBrightness() {
        ContentResolver contentResolver = getContentResolver();
        int defVal = 125;
        return Settings.System.getInt(contentResolver,
                Settings.System.SCREEN_BRIGHTNESS, defVal);
    }

    private final int writingSettingsRequestCode = 9999;
    private boolean pendingCheckPermission;
    private boolean checkPermissionResult;

    private void checkPermission() {
        if (pendingCheckPermission) return;
        pendingCheckPermission = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivityForResult(intent, writingSettingsRequestCode);
            } else {
                checkPermissionResult = true;
            }
        } else {
            pendingCheckPermission = false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case writingSettingsRequestCode:
                if (resultCode == RESULT_OK) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Settings.System.canWrite(this)) {
                            checkPermissionResult = true;
                        }
                    }
                }
                pendingCheckPermission = false;
                break;
        }
    }

    private Handler UIHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UIHandler = new Handler();
        register = findViewById(R.id.register);
        unregister = findViewById(R.id.unregister);
        container = findViewById(R.id.container);
        text = findViewById(R.id.text);
        ttsText = findViewById(R.id.tts);

        serviceIntent = new Intent();
        ComponentName componentName = new ComponentName(IVAService.PACKAGE, IVAService.CLASS);
        serviceIntent.setComponent(componentName);

        //startService(serviceIntent);
        mDeviceControl.setBrightnessListener(brightnessListener);
        iat.setIAT(this::onIAT);
        tts.setTTS(this::onTTS);
    }

    private boolean pendingRegisterEvent = false;

    public void register(View v) {
        if (pendingRegisterEvent) return;
        pendingRegisterEvent = true;

        UIHandler.post(() -> {
            if (mService != null && mService.asBinder().pingBinder()) {
                mService.registerModule(mDeviceControl);
                showTip("register " + mDeviceControl.getName().toString());
                mService.registerModule(iat);
                showTip("register " + iat.getName().toString());
                mService.registerModule(tts);
                showTip("register " + tts.getName().toString());
                mService.registerModule(wakeup);
                pendingRegisterEvent = false;// consume
            } else {
                bindService(serviceIntent, serviceConnection, BIND_AUTO_CREATE);
            }
        });
    }

    private void showTip(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private boolean pendingUnregisterEvent = false;

    public void unregister(View v) {
        if (pendingUnregisterEvent) return;
        pendingUnregisterEvent = true;

        UIHandler.post(() -> {
            if (mService != null && mService.asBinder().pingBinder()) {
                mService.unregisterModule(mDeviceControl);
                showTip("unregister " + mDeviceControl.getName().toString());
                mService.unregisterModule(iat);
                showTip("unregister " + iat.getName().toString());
                mService.unregisterModule(tts);
                showTip("unregister " + tts.getName().toString());
                pendingUnregisterEvent = false;// consume
            } else {
                bindService(serviceIntent, serviceConnection, BIND_AUTO_CREATE);
            }
        });
    }

    private boolean pendingWakeupEvent = false;

    public void wakeup(View view) {
        if (pendingWakeupEvent) return;
        pendingWakeupEvent = true;
        UIHandler.post(() -> {
            if (mService != null && mService.asBinder().pingBinder()) {
                mService.wakeup();
                showTip("wakeup");
                pendingWakeupEvent = false;// consume
            } else {
                bindService(serviceIntent, serviceConnection, BIND_AUTO_CREATE);
            }
        });
    }

    @Override
    public void onIAT(String text, boolean end) {
        UIHandler.post(() -> {
            VAClientActivity.this.text.setText(text);
            if (end) {
                Log.w(TAG, "complete");
            }
        });
    }

    StringBuilder sb = new StringBuilder();
    List<TTSDirective> directives = new ArrayList<>();
    String display = "";
    TTSDirective last;
    @Override
    public void onTTS(TTSDirective directive) {
        Log.d(TAG, String.format("tts percent \t%d%s", directive.percent,"%"));
        if (directive.state == 0) {
            directives.clear();
            sb.delete(0, sb.length());

            sb.append(directive.text);
            display = sb.toString();
            last = directive;
            UIHandler.post(() -> ttsText.setText(display + ""));
            return;
        }

        if (directive.state == 1 ) {
            directives.add(directive);

            if (directive.percent > last.percent) {
                sb.append(directive.text);
                display = sb.toString();
                UIHandler.post(() -> ttsText.setText(display + ""));
            }
            last = directive;
        }

        if (directive.state == 2) {

        }
    }

    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
