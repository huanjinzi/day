package com.svr.va.demo;

import com.svr.va.remote.directive.TTSDirective;
import com.svr.va.remote.module.TTSModule;

public class TTS extends TTSModule {

    private TTSListener listener;
    @Override
    public void handleDirective(TTSDirective directive) {
        if (listener != null) {
            listener.onTTS(directive);
        }
    }

    public void setTTS(TTSListener listener) {
        this.listener = listener;
    }

    interface TTSListener {
        void onTTS(TTSDirective directive);
    }
}
