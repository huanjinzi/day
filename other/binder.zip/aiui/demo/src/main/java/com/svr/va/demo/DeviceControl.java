/*
 *  Copyright (C) 2019 Skyworth New World Inc.
 */
package com.svr.va.demo;

import android.util.Log;


import com.svr.va.remote.directive.Directive;
import com.svr.va.remote.directive.DirectiveName;
import com.svr.va.remote.module.Module;
import com.svr.va.remote.module.ModuleName;

import java.util.ArrayList;
import java.util.List;

public class DeviceControl extends Module {

    private final static String TAG = "va_DeviceControl";
    private static ModuleName name = new ModuleName("ISKYWORTH.IDeviceControl");

    private static final DirectiveName BRIGHTNESS_UP = new DirectiveName("brightnessUp");
    private static final DirectiveName BRIGHTNESS_DOWN = new DirectiveName("brightnessDown");

    private BrightnessListener brightnessListener;

    private ArrayList supportDirective = new ArrayList() {
        {
            add(BRIGHTNESS_UP);
            add(BRIGHTNESS_DOWN);
        }
    };

    @Override
    public void handleDirective(Directive directive) {
        Log.d(TAG, "remote module directive:" + directive.getName());
        DirectiveName name = directive.getName();
        if (name.equals(BRIGHTNESS_UP)) {
            //
            if (brightnessListener != null) {
                brightnessListener.onBrightnessUp();
            }
        } else if (name.equals(BRIGHTNESS_DOWN)) {
            if (brightnessListener != null) {
                brightnessListener.onBrightnessDown();
            }
        }
    }

    @Override
    public List<DirectiveName> supportDirective() {
        return null;
        //return supportDirective;
    }

    @Override
    public ModuleName getName() {
        return name;
    }

    void setBrightnessListener(BrightnessListener listener) {
        brightnessListener = listener;
    }

    public interface BrightnessListener{
        void onBrightnessUp();
        void onBrightnessDown();
    }

}
