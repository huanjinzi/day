# dvd specification

## 获取`DVDManagerService`

```
DVDManagerService dvd = DVDManagerService.Singleton;
```

## 连接

```
dvd.connect();
```
## 访问根目录
```
// default is '/'
DVDFile root = new DVDFile();
```

## 遍历目录
只有在光盘准备好的情况下才可以遍历文件
```
public void travel(DVDFile root) {
        try {
            for (DVDFile f : root.listFiles()) {
                travel(f);
            }

            // file
            if (!root.isDir()) {
                Log.d("DVD", root.getName());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
}
```

## 获取url
```
root.getUrl();
```


## 完整代码
```
DVDManagerService dvd = DVDManagerService.Singleton;
        dvd.addConnectedListener(new ConnectionListener() {
            @Override
            public void onSuccess() {
                Log.d("ConnectionListener","onSuccess");
            }

            @Override
            public void onTimeout() {
                Log.d("ConnectionListener","onTimeout");
            }

            @Override
            public void onError() {
                Log.d("ConnectionListener","onError");
            }
        });

        dvd.addDiskStateListener(new OnDiskStateChangeListener() {
            @Override
            public void onDiskFind() {

            }

            @Override
            public void onDiskReady() {
                // only on disk ready can travel files.
                DVDFile root = new DVDFile();
                travel(root);
            }
        });

        dvd.addConnectedListener(new ConnectionListener() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onTimeout() {

            }

            @Override
            public void onError() {

            }
        });
        dvd.connect();
    }

    public void travel(DVDFile root) {
        try {
            for (DVDFile f : root.listFiles()) {
                travel(f);
            }

            // file
            if (!root.isDir()) {
                Log.d("DVD", root.getName());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

