package com.ssnwt.dvd;

public interface OnDiskStateChangeListener {

    int Find = 0;
    int Ready = 1;

    void onDiskFind();
    void onDiskReady();
}
