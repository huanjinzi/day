package com.ssnwt.dvd;

import org.fourthline.cling.model.types.UnsignedIntegerFourBytes;
import org.fourthline.cling.model.types.UnsignedIntegerTwoBytes;
import org.fourthline.cling.support.model.Channel;
import org.fourthline.cling.support.renderingcontrol.AbstractAudioRenderingControl;
import org.fourthline.cling.support.renderingcontrol.RenderingControlException;

public class AudioRenderingControl extends AbstractAudioRenderingControl {
    @Override
    public boolean getMute(UnsignedIntegerFourBytes unsignedIntegerFourBytes, String s) throws RenderingControlException {
        return false;
    }

    @Override
    public void setMute(UnsignedIntegerFourBytes unsignedIntegerFourBytes, String s, boolean b) throws RenderingControlException {

    }

    @Override
    public UnsignedIntegerTwoBytes getVolume(UnsignedIntegerFourBytes unsignedIntegerFourBytes, String s) throws RenderingControlException {
        return null;
    }

    @Override
    public void setVolume(UnsignedIntegerFourBytes unsignedIntegerFourBytes, String s, UnsignedIntegerTwoBytes unsignedIntegerTwoBytes) throws RenderingControlException {

    }

    @Override
    protected Channel[] getCurrentChannels() {
        return new Channel[0];
    }

    @Override
    public UnsignedIntegerFourBytes[] getCurrentInstanceIds() {
        return new UnsignedIntegerFourBytes[0];
    }
}
