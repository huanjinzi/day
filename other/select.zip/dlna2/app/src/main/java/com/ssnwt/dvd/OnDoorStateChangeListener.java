package com.ssnwt.dvd;

public interface OnDoorStateChangeListener {

    int Lock = 0;
    int UnLock = 1;

    void onLock();
    void onUnLock();
}
