package com.ssnwt.dvd;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.util.Log;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public enum DVDManagerService {
    Singleton;
    public static final String TAG = "DVDManagerService";

    private Selector selector;
    float selectSpeed;
    float selectSpeedLimit = 500;
    Control control;
    private ArrayList<ConnectionListener> connectListeners = new ArrayList<>();
    private ArrayList<OnDiskStateChangeListener> diskStateListeners = new ArrayList<>();
    private ArrayList<OnDoorStateChangeListener> doorStateListeners = new ArrayList<>();

    public Thread main;
    private HandlerThread notify;
    Handler handler;

    // 3480 dvd
    // 3481 p81
    // 3482 info
    // 3483 mtb
    /* !!! Please Don't Rearrange This Array. !!! */
    private String[] channels = {"dvd", "p81", "info", "mtb"};
    private static final String HOST = "192.168.1.1";

    private Map<String, SocketChannel> channelMap = new HashMap<>();
    private Map<String, InetSocketAddress> addressMap = new HashMap<>();
    private ByteBuffer buffer = ByteBuffer.allocate(100);
    private OkHttpClient client;
    private boolean quiteSelect = false;

    DVDManagerService() {
        Log.i(TAG, "version name:" + BuildConfig.VERSION_NAME);
        Log.i(TAG, "version code:" + BuildConfig.VERSION_CODE);
        Log.i(TAG, "build type:" + BuildConfig.BUILD_TYPE);

        try {
            selector = Selector.open();
        } catch (IOException e) {
            Log.e(TAG, e.toString());
        }

        for (int port = 3480; port < 3484; port++) {
            InetSocketAddress address = new InetSocketAddress(HOST, port);
            addressMap.put(channels[port - 3480], address);
        }

        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        //builder.addNetworkInterceptor(new NetInterceptor());
        client = builder.build();

        main = new Thread(new Runnable() {
            @Override
            public void run() {
                DVDManagerService.this.run();
            }
        }, TAG + "-main");

        notify = new HandlerThread(TAG + "-notify");
        notify.start();
        handler = new Handler(notify.getLooper());
        control = new Control();
    }


    void run() {
        long deltaTime;
        long lastTime;
        while (true) {
            try {
                lastTime = SystemClock.uptimeMillis();
                selector.select();
                deltaTime = SystemClock.uptimeMillis() - lastTime;
                Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();
                    iterator.remove();  // Why remove it?
                    process(key);
                }

                // profile sample.
                profile(deltaTime);

            } catch (Exception e) {
                e.printStackTrace();
            }

            if (quiteSelect) {
                // close socket channel.
                for (String name : channels) {
                    SocketChannel channel = channelMap.get(name);
                    if (channel != null) {
                        try {
                            channel.close();
                        } catch (IOException e) {
                            Log.w(TAG, e.toString());
                        }
                    }
                }

                // close selector.
                try {
                    selector.close();
                } catch (IOException e) {
                    Log.w(TAG, e.toString());
                }

                Log.w(TAG, "loop exit.");
                break;
            }
        }
    }

    /** */
    void process(SelectionKey event) throws Exception {
        buffer.clear();
        String eventType = (String) event.attachment();
        Log.d(TAG, "socket event:" + eventType + " " + event.isReadable());
        if (event.isReadable()) {
            SocketChannel channel = (SocketChannel) event.channel();
            channel.read(buffer);

            byte[] ret = new byte[buffer.flip().limit()];
            buffer.get(ret).clear();
            Log.d(TAG, new String(ret));
            Log.d(TAG, Arrays.toString(ret));

            if (Arrays.equals(ret, Command.CONNECTACCEPT)) {
                Log.d(TAG, "connect success.");
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DVDManagerService.this.notifyConnectStateChanged(ConnectionListener.Success);
                    }
                });

            } else if (Arrays.equals(ret, Command.MTSCANOK)) {
                // request auth,get sid.
                if (!auth()) {
                    Log.e(TAG, "auth error!");
                }
                Log.d(TAG, "auth complete.");
                if (DVDFile.getMode() == Mode.UPnP) {
                    control.bindService();
                }
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (DVDFile.getMode() == Mode.HTTP) {
                            DVDManagerService.this.notifyDiskStateChanged(OnDiskStateChangeListener.Ready);
                        }
                    }
                });
            } else if (Arrays.equals(ret, Command.IN)) {
                Log.d(TAG, "door lock");
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DVDManagerService.this.notifyDoorStateChanged(OnDoorStateChangeListener.Lock);
                    }
                });

            } else if (Arrays.equals(ret, Command.OUT)) {
                Log.d(TAG, "door unlock");
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DVDManagerService.this.notifyDoorStateChanged(OnDoorStateChangeListener.UnLock);
                    }
                });

            } else if (new String(ret).contains(new String(Command.DISCIN))) {
                Log.d(TAG, "disk in");
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DVDManagerService.this.notifyDiskStateChanged(OnDiskStateChangeListener.Find);
                    }
                });
            }
        }
    }

    Queue<Long> profileQueue = new LinkedList<>();
    Queue<Long> limiterQueue = new LinkedList<>();
    void profile(long deltaTime) {
        profileQueue.offer(deltaTime);
        if (profileQueue.size() > 4) {
            profileQueue.poll();
        }

        // calculate speed.
        long sum = 0;
        for (Long delta : profileQueue) {
            sum += delta;
        }

        selectSpeed = (float) sum / profileQueue.size();
        Log.w(TAG, "select speed:" + selectSpeed);

        if (selectSpeed < selectSpeedLimit) {
            limiterQueue.offer(calculateStep(selectSpeedLimit, selectSpeed,limiterQueue.size()));
        } else {
            limiterQueue.poll();
        }

        long sleepTime = 0;
        for (Long time : limiterQueue) {
            sleepTime += time;
        }

        try {
            Log.w(TAG, "sleep time:" + sleepTime);
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //
    long calculateStep(float target, float now,int adj) {
        return (long) (100 + Math.abs(target - now) / target * Math.pow(8, adj));
    }

    void notifyConnectStateChanged(int state) {
        Log.d(TAG, "notifyConnect");
        connectExist = false;
        if (state == ConnectionListener.Timeout || state == ConnectionListener.Error) {
            close();
        }
        for (ConnectionListener l : connectListeners) {
            switch (state) {
                case ConnectionListener.Success:
                    handler.removeCallbacks(timeoutTask);
                    l.onSuccess();
                    break;
                case ConnectionListener.Timeout:
                    l.onTimeout();
                    break;
                case ConnectionListener.Error:
                    l.onError();
                    break;
            }
        }
    }

    void close() {
        for (String k : channelMap.keySet()) {
            SocketChannel socket = channelMap.get(k);
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    void notifyDiskStateChanged(int state) {
        Log.d(TAG, "notifyDiskStateChanged");
        for (OnDiskStateChangeListener l : diskStateListeners) {
            switch (state) {
                case OnDiskStateChangeListener.Find:
                    l.onDiskFind();
                    break;
                case OnDiskStateChangeListener.Ready:
                    l.onDiskReady();
                    break;
            }
        }
    }

    void notifyDoorStateChanged(int state) {
        Log.d(TAG, "notifyDoorStateChanged " + state);
        for (OnDoorStateChangeListener l : doorStateListeners) {
            switch (state) {
                case OnDoorStateChangeListener.Lock:
                    l.onLock();
                    break;
                case OnDoorStateChangeListener.UnLock:
                    l.onUnLock();
                    break;
            }
        }
    }

    public void connect() {
        connect(0);
    }

    boolean connectExist;
    Runnable timeoutTask = new Runnable() {
        @Override
        public void run() {
            DVDManagerService.this.notifyConnectStateChanged(ConnectionListener.Timeout);
        }
    };

    public void connect(long timeout) {
        // race condition
        if (connectExist) {
            Log.w(TAG, "there exist a connection.");
            return;
        }

        connectExist = true;
        if (timeout > 0) {
            handler.postDelayed(timeoutTask, timeout);
        }
        for (String name : channels) {
            SocketChannel socket = channelMap.get(name);
            int tryTimes = 10;

            while (socket == null || !socket.isConnected()) try {

                socket = SocketChannel.open(addressMap.get(name));
                channelMap.put(name, socket);
                socket.configureBlocking(false);

                // maybe block, send a wakeup signal to selector.
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        selector.wakeup();
                    }
                }, 100);
                socket.register(selector, SelectionKey.OP_READ, name);

            } catch (Exception e) {
                Log.d(TAG, e.getMessage() + "");
                tryTimes--;
                if (tryTimes < 0) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            DVDManagerService.this.notifyConnectStateChanged(ConnectionListener.Error);
                        }
                    });
                    return;
                }
            }
        }

        if (main.getState() == Thread.State.NEW) {
            main.start();
        }

        SocketChannel dvd = channelMap.get("dvd");
        if (dvd != null) {
            try {
                dvd.write(ByteBuffer.wrap(Command.CONNECT));
            } catch (IOException e) {
                e.printStackTrace();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        DVDManagerService.this.notifyConnectStateChanged(ConnectionListener.Error);
                    }
                });
            }
        }
    }

    /**
     * DVD Command class.
     */
    static class Command {
        public static final byte[] CONNECT = "CONNECT\n\n".getBytes();
        public static final byte[] CONNECTACCEPT = "CONNECTACCEPT\n\n".getBytes();
        public static final byte[] FWVersion = "FWVersion\n\n".getBytes();
        public static final byte[] MTSCANOK = "MTSCANOK\n".getBytes();
        public static final byte[] MTSCAN = "MTSCAN\n".getBytes();
        public static final byte[] CheckDB = "CheckDB\n\n".getBytes();
        public static final byte[] InsertOK = "InsertOK\n\n".getBytes();
        public static final byte[] OUT = "OUT\n\0".getBytes();
        public static final byte[] IN = "IN\n\0".getBytes();
        public static final byte[] DISCIN = "DISCIN\n".getBytes();
        public static final byte[] LOCKDOOR = "LOCKDOOR\n\n".getBytes();
        public static final byte[] UNLOCKDOOR = "UNLOCKDOOR\n\n".getBytes();
        public static final byte[] LOCKOK = "LOCKOK\n\n".getBytes();

    }

    /**
     * remove unused http header.
     */
    class NetInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            request = request.newBuilder()
                    .removeHeader("User-Agent")
                    .removeHeader("Accept-Encoding")
                    .build();
            Response response = chain.proceed(request);
            if (response.body() != null && response.body().contentType() != null) {
                MediaType mediaType = response.body().contentType();
                String content = response.body().string();
                ResponseBody responseBody = ResponseBody.create(mediaType, content);
                return response.newBuilder().body(responseBody).build();
            } else {
                return response;
            }
        }

    }

    boolean auth() {
        String url = "http://192.168.1.1:12000/content/interface?req_type=auth&return_type=xml&sid=&action=get_sid";
        Request.Builder builder = new Request.Builder();
        builder.url(url);

        try (Response response = client.newCall(builder.build()).execute();
             ResponseBody body = response.body()
        ) {
            String content = body == null ? "" : body.string();

            Document document = DocumentHelper.parseText(content);
            Element root = document.getRootElement();

            String sid = root.attribute("success").getValue();
            return sid.equals("1");

        } catch (Exception e) {
            Log.e(TAG, e.toString());
        }
        return false;
    }

    public Object diskListenerLock = new Object();

    public void addDiskStateListener(OnDiskStateChangeListener l) {
        synchronized (diskListenerLock) {
            if (!diskStateListeners.contains(l)) {
                diskStateListeners.add(l);
            }

        }
    }

    public void removeDiskStateListener(OnDiskStateChangeListener l) {
        synchronized (diskListenerLock) {
            diskStateListeners.remove(l);
        }
    }

    public Object doorListenerLock = new Object();

    public void addDoorStateListener(OnDoorStateChangeListener l) {
        synchronized (doorListenerLock) {
            if (!doorStateListeners.contains(l)) {
                doorStateListeners.add(l);
            }
        }
    }

    public void removeDoorStateListener(OnDoorStateChangeListener l) {
        synchronized (doorListenerLock) {
            doorStateListeners.remove(l);
        }
    }

    public Object connectListenerLock = new Object();

    public void addConnectedListener(ConnectionListener l) {
        synchronized (connectListenerLock) {
            if (!connectListeners.contains(l)) {
                connectListeners.add(l);
            }
        }
    }

    public void removeConnectedListener(ConnectionListener l) {
        synchronized (connectListenerLock) {
            connectListeners.remove(l);
        }
    }

    public void destroy() {
        quiteSelect = true;
        selector.wakeup();
        notify.quit();
    }
}
