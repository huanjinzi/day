package com.ssnwt.dvd;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import com.unity3d.player.UnityPlayer;

import org.fourthline.cling.android.AndroidUpnpService;
import org.fourthline.cling.model.action.ActionInvocation;
import org.fourthline.cling.model.message.UpnpResponse;
import org.fourthline.cling.model.message.header.STAllHeader;
import org.fourthline.cling.model.meta.RemoteDevice;
import org.fourthline.cling.model.meta.Service;
import org.fourthline.cling.model.types.ServiceId;
import org.fourthline.cling.model.types.UDAServiceId;
import org.fourthline.cling.registry.DefaultRegistryListener;
import org.fourthline.cling.registry.Registry;
import org.fourthline.cling.registry.RegistryListener;
import org.fourthline.cling.support.contentdirectory.callback.Browse;
import org.fourthline.cling.support.model.BrowseFlag;
import org.fourthline.cling.support.model.DIDLContent;
import org.fourthline.cling.support.model.Res;
import org.fourthline.cling.support.model.container.Container;
import org.fourthline.cling.support.model.item.Item;

import java.util.ArrayList;
import java.util.concurrent.locks.LockSupport;

public class Control {
    public static final String TAG = "ControlPoint";
    public static final String CONTENT_DIRECTORY = "ContentDirectory";
    private Context context;

    private AndroidUpnpService mUpnpService;

    public void bindService() {
        if (context == null) {
            boolean result = UnityPlayer.currentActivity.bindService(new Intent(UnityPlayer.currentActivity, ControlService.class),
                    serviceConnection,
                    Context.BIND_AUTO_CREATE);
            if (!result) {
                Log.e(TAG,"bind service error");
            }
        } else {
            boolean result = context.bindService(new Intent(context, ControlService.class),
                    serviceConnection,
                    Context.BIND_AUTO_CREATE);
            if (!result) {
                Log.e(TAG,"bind service error");
            }
        }

    }

    public void setContext(Context context) {
        this.context = context;
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            Log.d(TAG, "upnp service bind success");
            mUpnpService = (AndroidUpnpService) service;
            // Register the device when this activity binds to the service for the first time
            try {
                mUpnpService.getRegistry().addListener(
                        createRegistryListener(mUpnpService)
                );

                mUpnpService.getControlPoint().search(new STAllHeader());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void onServiceDisconnected(ComponentName className) {
            mUpnpService = null;
        }
    };

    ServiceContext serviceContext;
    RegistryListener createRegistryListener(final AndroidUpnpService upnpService) {
        return new DefaultRegistryListener() {
            ServiceId contentDirectory = new UDAServiceId(CONTENT_DIRECTORY);
            @Override
            public void remoteDeviceAdded(Registry registry, RemoteDevice device) {
                Log.d(TAG, device.toString());
                Service contentDirectoryService;
                if ((contentDirectoryService = device.findService(contentDirectory)) != null) {
                    serviceContext = new ServiceContext(upnpService, contentDirectoryService);
                    Log.d(TAG, "find ContentDirectory service");
                    // notify data ready
                    DVDManagerService.Singleton.notifyDiskStateChanged(OnDiskStateChangeListener.Ready);
                }
            }

            @Override
            public void remoteDeviceRemoved(Registry registry, RemoteDevice device) {
                Log.d(TAG, device.toString());
                if (device.findService(contentDirectory) != null) {
                    // notify connect error.
                    DVDManagerService.Singleton.notifyConnectStateChanged(ConnectionListener.Error);
                }
            }

        };
    }

    void browse(final ArrayList<DVDFile> files, final DVDFile parent, final ServiceContext ctx, String id) {
        ctx.upnp.getControlPoint().execute(new Browse(ctx.service,id,BrowseFlag.DIRECT_CHILDREN) {
            @Override
            public void received(ActionInvocation actionInvocation, DIDLContent didlContent) {
//                ActionArgumentValue value = actionInvocation.getOutput("Result");
//                try {
//                    Document doc = DocumentHelper.parseText(value.toString());
//                    OutputFormat format = new OutputFormat();
//                    format.setEncoding("UTF-8");
//                    format.setNewlines(true);
//                    format.setIndent("    ");
//                    format.setIndent(true);
//
//                    StringWriter s = new StringWriter();
//                    XMLWriter writer = new XMLWriter(s, format);
//                    try {
//                        writer.write(doc);
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//
//                    //Log.w(TAG,s.toString());
//
//                } catch (DocumentException e) {
//                    e.printStackTrace();
//                }

                // file
                for (Item item: didlContent.getItems()) {
                    Log.i(TAG, item.getTitle());
                    DVDFile file = new DVDFile();
                    file.id = item.getId();
                    file.parentId = item.getParentID();
                    file.isDir = false;
                    file.pathStack.addAll(parent.pathStack);
                    file.pathStack.push(item.getTitle());
                    Res res = item.getFirstResource();
                    if (res != null) {
                        file.url = res.getValue();
                        file.mime = res.getProtocolInfo().getContentFormatMimeType();
                        file.size = res.getSize();
                    }
                    files.add(file);
                }

                // dir
                for (Container container : didlContent.getContainers()) {
                    //Log.i(TAG, "container:id= " + container.getId());
                    //Log.i(TAG, "container:title= " + container.getTitle());
                    DVDFile file = new DVDFile();
                    file.id = container.getId();
                    file.parentId = container.getParentID();
                    file.pathStack.addAll(parent.pathStack);
                    file.pathStack.push(container.getTitle());
                    file.isDir = true;
                    file.childCount = container.getChildCount();
                    files.add(file);
                }
                LockSupport.unpark(DVDFile.lastThread);
            }

            @Override
            public void updateStatus(Status status) {
                Log.i(TAG, "status:" + status.toString());
            }

            @Override
            public void failure(ActionInvocation actionInvocation, UpnpResponse upnpResponse, String s) {
                Log.e(TAG, "failure:" + upnpResponse.toString() + "," + s);
            }
        });

    }

    class ServiceContext {
        AndroidUpnpService upnp;
        Service service;

        ServiceContext(AndroidUpnpService upnp,Service service) {
            this.upnp = upnp;
            this.service = service;
        }
    }
}
