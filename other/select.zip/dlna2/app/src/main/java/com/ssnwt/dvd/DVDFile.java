package com.ssnwt.dvd;

import android.util.Log;
import android.util.LruCache;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.seamless.util.MimeType;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;
import java.util.concurrent.locks.LockSupport;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class DVDFile {
    private static LruCache<String, DVDFile[]> cache = new LruCache<>(50);
    private static LruCache<String, DVDFile[]> cacheUPnP = new LruCache<>(50);
    public static final String TAG = "DVDFile";
    private static final String HOST = "http://192.168.1.1:8080";
    Stack<String> pathStack = new Stack<>();
    String id = "0";
    String parentId = "0";
    private static Mode mode = Mode.UPnP;
    String path = "/";
    String url = HOST;
    MimeType mime;
    long size;
    int childCount;
    boolean isDir = true;
    private static OkHttpClient client = new OkHttpClient();

    public String getPath() {
        if (isDir) {
            return stackToPath(pathStack);
        } else {
            Stack<String> temp = (Stack<String>) pathStack.clone();
            temp.pop();
            return stackToPath(temp);
        }
    }

    public static void setMode(Mode mode) {
        DVDFile.mode = mode;
    }

    public static Mode getMode() {
        return mode;
    }

    public String getName() {
        return pathStack.peek();
    }

    public boolean isDir() {
        return isDir;
    }

    private String stackToPath(Stack<String> stack) {
        StringBuilder sb = new StringBuilder();
        sb.append("/");
        while (!stack.empty()) {
            // if path is '/a/b/c',Stack top is 'c',
            // so,insert in front of StringBuilder.
            sb.insert(0, stack.pop());
            sb.insert(0,"/");
        }
        return sb.toString();
    }

    public void setPath(String path) {
        // Cation:head match and end match
        Log.d(TAG, "setPath:" + path);
        for (String p : path.trim().split("[/]+")) {
            if (p.trim().isEmpty() || p.trim().equals(".")) {
                continue;
            }

            if (p.trim().equals("..")) {
                if (!pathStack.empty()) {
                    pathStack.pop();
                }
            } else {
                pathStack.push(p);
            }
        }


        Stack<String> temp = (Stack<String>) pathStack.clone();
        this.path = stackToPath(temp);
        Log.w(TAG, this.path + ",tempSize=" + temp.size() + ",pathSize=" + pathStack.size());
        this.url = HOST + this.path;
    }

    /**
     * this method will be blocked until DVD MediaTomb/Web Server has response.
     * @return list dir files.
     * @throws IOException network error.
     * */
    public DVDFile[] listFiles() throws IOException {
        if (getMode() == Mode.UPnP) {
            return listUPnPFiles();
        }
        Log.d(TAG, cache.toString());
        DVDFile[] c = cache.get(path);
        if (c != null) {
            return c;
        }
        if (!isDir) return new DVDFile[0];
        String url = getUrl();
        Request request = new Request.Builder().url(url).build();
        Response response = client.newCall(request).execute();
        ResponseBody body = response.body();
        Document doc = Jsoup.parse(body == null ? "" : body.string());

        if (body != null) {
            body.close();
        }

        ArrayList<DVDFile> files = new ArrayList<>();
        Element root = doc.body();
        it(files, root);

        //remove our-self and '/',otherwise,maybe cause infinite loop.
        Iterator<DVDFile> iterator = files.iterator();
        while (iterator.hasNext()) {
            DVDFile f = iterator.next();
            if (!f.isDir) {
                continue;
            }

            if (f.getPath().equals(getPath())) {
                iterator.remove();
            } else if (f.getPath().equals("/")) {
                iterator.remove();
            }
        }

        DVDFile[] r = files.toArray(new DVDFile[]{});
        cache.put(path, r);
        return r;
    }

    public static final Object browseBroker = new Object();
    public static Thread lastThread;
    /** upnp */
    private synchronized DVDFile[] listUPnPFiles() {
        Log.d(TAG, cacheUPnP.toString());
        DVDFile[] c = cacheUPnP.get(id);
        if (c != null) {
            return c;
        }
        if (!isDir) return new DVDFile[0];
        Control control = DVDManagerService.Singleton.control;
        Control.ServiceContext ctx = control.serviceContext;
        ArrayList<DVDFile> files = new ArrayList<>();
        lastThread = Thread.currentThread();

        control.browse(files,this,ctx,id);

        LockSupport.park(browseBroker);
        DVDFile[] r = files.toArray(new DVDFile[]{});
        cacheUPnP.put(id, r);
        return r;
    }

    public String getType() {
        if(!isDir()) {
            String fileName = getName();
            String[] seq = fileName.split("[.]");

            if (seq.length >= 2) {
                return seq[seq.length -1];
            }
        }
        return null;
    }

    /** get the url of this.*/
    public String getUrl() {
        if (mode == Mode.HTTP && !isDir) {
            return url.substring(0, url.length() - 1);
        }

        return url;
    }

    public void it(ArrayList<DVDFile> files, Element root) {
        for (Element e : root.children()) {
            if (e.tagName().equals("tbody")) {
                Elements trs = e.children();
                row:
                for (Element tr : trs) {
                    DVDFile file = new DVDFile();
                    Elements tds = tr.children();
                    for (Element td : tds) {
                        switch (td.className().trim()) {
                            case "n":
                                Element a = td.child(0);
                                String url = a.attr("href").trim();
                                if (url.equals("../")) {
                                    continue row;
                                }
                                file.setPath(path + URLDecoder.decode(url));
                                break;
                            case "t":
                                if (td.text().trim().equals("Directory")) {
                                } else {
                                    //file.mime = td.text().trim();
                                    file.isDir = false;
                                }
                                break;
                        }
                    }
                    files.add(file);
                }
            }
            it(files, e);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        sb.append(getPath());
        sb.append(",");
        sb.append(isDir);
        sb.append(",");
        sb.append(getUrl());
        if (!isDir) {
            sb.append(",");
            sb.append(mime);
        }
        sb.append("]");
        return sb.toString();
    }
}
