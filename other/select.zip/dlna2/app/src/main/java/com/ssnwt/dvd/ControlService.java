package com.ssnwt.dvd;

import org.fourthline.cling.android.AndroidUpnpServiceImpl;

public class ControlService extends AndroidUpnpServiceImpl {
}
