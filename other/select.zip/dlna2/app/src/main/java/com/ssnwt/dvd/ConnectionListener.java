package com.ssnwt.dvd;

public interface ConnectionListener {
    int Success = 0;
    int Timeout = 1;
    int Error = 2;

    void onSuccess();
    void onTimeout();
    void onError();
}
