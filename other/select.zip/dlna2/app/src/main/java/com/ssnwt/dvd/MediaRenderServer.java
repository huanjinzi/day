package com.ssnwt.dvd;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;

import org.fourthline.cling.android.AndroidUpnpService;
import org.fourthline.cling.binding.annotations.AnnotationLocalServiceBinder;
import org.fourthline.cling.model.DefaultServiceManager;
import org.fourthline.cling.model.meta.DeviceDetails;
import org.fourthline.cling.model.meta.DeviceIdentity;
import org.fourthline.cling.model.meta.Icon;
import org.fourthline.cling.model.meta.LocalDevice;
import org.fourthline.cling.model.meta.LocalService;
import org.fourthline.cling.model.meta.ManufacturerDetails;
import org.fourthline.cling.model.meta.ModelDetails;
import org.fourthline.cling.model.types.DeviceType;
import org.fourthline.cling.model.types.UDADeviceType;
import org.fourthline.cling.model.types.UDN;
import org.fourthline.cling.support.avtransport.impl.AVTransportService;
import org.fourthline.cling.support.connectionmanager.ConnectionManagerService;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class MediaRenderServer implements Runnable {
    public static final String TAG = "MediaRenderServer";
    private Context context;
    private AndroidUpnpService mUpnpService;

    public MediaRenderServer(Context context) {
        this.context = context;
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            mUpnpService = (AndroidUpnpService) service;
            // Register the device when this activity binds to the service for the first time
            try {
                mUpnpService.getRegistry().addDevice(createDevice());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        public void onServiceDisconnected(ComponentName className) {
            mUpnpService = null;
        }
    };

    @Override
    public void run() {
        context.bindService(
                new Intent(context, MediaRenderService.class),
                serviceConnection,
                Context.BIND_AUTO_CREATE
        );
    }

    public LocalDevice createDevice() throws Exception {
        DeviceIdentity identity = new DeviceIdentity(new UDN(UUID.randomUUID()));
        DeviceType type = new UDADeviceType("MediaRenderer", 1);
        DeviceDetails details = new DeviceDetails("DVD Player MediaRender",
                new ManufacturerDetails("Skyworth"),
                new ModelDetails("V901",
                        "8K decoder",
                        "1"));

        InputStream in = context.getResources().openRawResource(R.raw.icon);
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            while ((len = in.read(buffer)) != -1) {
                bos.write(buffer, 0, len);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Icon icon = new Icon("image/png",
                48, 48, 8, "icon.png",bos.toByteArray());

        LocalService connection =
                new AnnotationLocalServiceBinder().read(ConnectionManagerService.class);

        connection.setManager(
                new DefaultServiceManager<>(
                        connection,
                        ConnectionManagerService.class
                )
        );


        LocalService av =
                new AnnotationLocalServiceBinder().read(AVTransportService.class);
        av.setManager(
                new DefaultServiceManager<>(
                        av,
                        AVTransportService.class
                )
        );

        LocalService audioCtrl =
                new AnnotationLocalServiceBinder().read(AudioRenderingControl.class);
        audioCtrl.setManager(
                new DefaultServiceManager<>(
                        audioCtrl,
                        AudioRenderingControl.class
                )
        );

        return new LocalDevice(identity,
                type,
                details,
                icon,
                new LocalService[]{av,
                        connection,
                        audioCtrl});

    }
}
