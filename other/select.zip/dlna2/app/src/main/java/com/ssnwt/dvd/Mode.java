package com.ssnwt.dvd;

public enum Mode {
    HTTP,UPnP
}
