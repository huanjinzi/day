package com.ssnwt.dvd;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import org.dom4j.DocumentHelper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.concurrent.locks.LockSupport;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {

    private OkHttpClient client;

    @Before
    public void init() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        //builder.addNetworkInterceptor(new NetInterceptor());
        client = builder.build();
    }

    @Test
    public void connect() {
        String TAG_CONNECT = "CONNECT";
        String commend = "CONNECT\n\n";
        try {

            Log.d(TAG_CONNECT, "start");
            InetSocketAddress address_80 = new InetSocketAddress("192.168.1.1", 3480);
            Socket socket_80 = new Socket();
            socket_80.connect(address_80, 0);
            Log.d(TAG_CONNECT, "end");

            Log.d(TAG_CONNECT, "start");
            InetSocketAddress address_81 = new InetSocketAddress("192.168.1.1", 3481);
            while (true) {
                try {
                    Socket socket_81 = new Socket();
                    socket_81.connect(address_81, 0);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    continue;
                }
                break;
            }

            Log.d(TAG_CONNECT, "end");

            Log.d(TAG_CONNECT, "start");
            InetSocketAddress address_82 = new InetSocketAddress("192.168.1.1", 3482);
            final Socket socket_82 = new Socket();
            socket_82.connect(address_82, 0);
            Log.d(TAG_CONNECT, "end");

            Log.d(TAG_CONNECT, "start");
            InetSocketAddress address_83 = new InetSocketAddress("192.168.1.1", 3483);

            Socket socket_83;
            while (true) {
                try {
                    socket_83 = new Socket();
                    socket_83.connect(address_83, 0);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    continue;
                }
                break;
            }

            Log.d(TAG_CONNECT, "end");

            Log.d(TAG_CONNECT, "start write");
            OutputStream os = socket_80.getOutputStream();
            os.write(commend.getBytes());
            os.flush();
            Log.d(TAG_CONNECT, "end write");

            Log.d(TAG_CONNECT, "start read");
            InputStream in = socket_80.getInputStream();
            InputStreamReader ir = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(ir);

            String ret = br.readLine();
            System.out.println(ret);

            final Socket socket_831 = socket_83;

            if (ret.equals("CONNECTACCEPT")) {
                String fw = "FWVersion\n\n";
                socket_831.getOutputStream().write(fw.getBytes());

                InputStream in_83 = socket_831.getInputStream();
                InputStreamReader ir_83 = new InputStreamReader(in_83);
                BufferedReader br_83 = new BufferedReader(ir_83);
                System.out.println("83:" + br_83.readLine());

                Thread t82 = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        print82(socket_82, socket_831);
                    }
                });

                t82.start();

                String diskInfo = "\n\n";
                socket_80.getOutputStream().write(diskInfo.getBytes());

                try {
                    t82.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void useAppContext() throws Exception {
        InetAddress group = InetAddress.getByName("239.255.255.250");
        MulticastSocket socket = new MulticastSocket();

        String msg = "M-SEARCH * HTTP/1.1\r\n" +
                "Host: 239.255.255.250:1900\r\n" +
                "Man: \"ssdp:discover\"\r\n" +
                "MX: 10\r\n" +
                "ST: upnp:rootdevice\r\n\r\n";
        DatagramPacket packet = new DatagramPacket(msg.getBytes(), msg.length(), group, 1900);
        socket.send(packet);

        // get their responses!
        byte[] buf = new byte[1000];
        DatagramPacket recv = new DatagramPacket(buf, buf.length);
        socket.receive(recv);

        System.out.println(buf);

        // OK, I'm done talking - leave the group...
        socket.leaveGroup(group);
    }

    @Test
    public void HttpProtocol() {
        final String TAG_HTTPPROTOCOL = "HTTPPROTOCOL";
        Log.d(TAG_HTTPPROTOCOL, "HttpProtocol ...............");
        String url = "http://192.168.1.1:8080/课程4（嵌入式LINUX内核驱动进阶班-下）/第3天（嵌入式Linux系统构建）/国嵌内核驱动进阶班-3-4（嵌入式文件系统）.avi";
        String content = null;

        //validate();

//        MediaPlayer mediaPlayer = new MediaPlayer();
//        try {
//            mediaPlayer.setDataSource(url);
//            mediaPlayer.prepare();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        SurfaceTexture surfaceTexture = new SurfaceTexture(false);
//        surfaceTexture.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
//            @Override
//            public void onFrameAvailable(SurfaceTexture surfaceTexture) {
//                surfaceTexture.updateTexImage();
//                long time = surfaceTexture.getTimestamp();
//                Log.d(TAG_HTTPPROTOCOL, time + "");
//            }
//        });
//        Surface surface = new Surface(surfaceTexture);
//        mediaPlayer.setSurface(surface);
//        mediaPlayer.start();


        try {
            content = run(url);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (content != null) {
            //Log.d("Test", content);
            Document doc = Jsoup.parse(content);

            Element root = doc.body();
            it(root);
        } else {
            Log.i("Test", "content is null");
        }
    }

    public void validate() {
        String url = "http://192.168.1.1:12000/content/interface?req_type=auth&return_type=xml&sid=&action=get_sid";

        Request.Builder builder = new Request.Builder();
        builder.url(url);

        try (Response response = client.newCall(builder.build()).execute();
             ResponseBody body = response.body()
        ) {
            String content = body == null ? "" : body.string();
            System.out.println(content);

            org.dom4j.Document document = DocumentHelper.parseText(content);
            org.dom4j.Element root = document.getRootElement();

            String sid = root.attribute("sid").getValue();

            System.out.println(sid);


        } catch (Exception e) {
        }


    }

    boolean out = false;

    public void it(Element root) {
        if (out) {
            return;
        }
        for (Element e : root.children()) {
            if (e.tagName().equals("tbody")) {

                Elements trs = e.children();
                for (Element tr : trs) {
                    Elements tds = tr.children();
                    for (Element td : tds) {
                        switch (td.className()) {
                            case "n":
                                td.text();
                                break;
                            case "s":
                                break;
                            case "m":
                                break;
                            case "t":
                                break;
                        }
                        System.out.println(td.className());
                        System.out.println(td.text());
                    }
                }
                out = true;
                return;
            }
            it(e);
        }
    }

    public String run(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
        try (ResponseBody body = response.body()) {

            long size = body.contentLength();
            InputStream in = body.byteStream();
            byte[] buffer = new byte[1024 * 10];
            int len;

            while ((len = in.read(buffer)) != -1) {

            }

            return "";
        }
    }

    public void dvd() {

    }


    public void print82(final Socket socket, final Socket socket_83) {
        try (
                InputStreamReader ir = new InputStreamReader(socket.getInputStream());
                BufferedReader br = new BufferedReader(ir)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("82:" + line);
                if (line.equals("MTSCANOK")) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {

                            HttpProtocol();
//                                String checkDB = "CheckDB\n\n";
//                                System.out.println("CheckDB");
//                                socket_83.getOutputStream().write(checkDB.getBytes());
//
//                                InputStream in_83 = socket_83.getInputStream();
//                                InputStreamReader ir_83 = new InputStreamReader(in_83);
//                                BufferedReader br_83 = new BufferedReader(ir_83);
//                                String ret = br_83.readLine();
//                                System.out.println(ret);
//
//                                if (ret.equals("InsertOK")) {
//                                    HttpProtocol();
//                                }

                        }
                    }).start();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void HttpProtocol1() throws Exception {
        Context context = InstrumentationRegistry.getContext();
        //File dir = context.getFilesDir();
        String url = "http://192.168.1.1:8080/课程4（嵌入式LINUX内核驱动进阶班-下）/第3天（嵌入式Linux系统构建）/国嵌内核驱动进阶班-3-4（嵌入式文件系统）.avi";
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
//
//        //File file = new File(dir.getPath() + "/linux.avi");
        ResponseBody body = response.body();
//        //OutputStream os = new FileOutputStream(file)
        InputStream in = body.byteStream();
        byte[] buffer = new byte[100];
//        int len;
//
        StringBuilder sb = new StringBuilder();
        in.read(buffer);
        System.out.println(Arrays.toString(buffer));
//        Log.i("xxx", "download complete");

    }


    @Test
    public void upnp() throws Exception {
        DVDManagerService.Singleton.addConnectedListener(new ConnectionListener() {
            @Override
            public void onSuccess() {
                Log.d(Control.TAG, "onSuccess");
            }

            @Override
            public void onTimeout() {
                Log.d(Control.TAG, "onTimeout");
            }

            @Override
            public void onError() {
                Log.d(Control.TAG, "onError");
            }
        });

        DVDManagerService.Singleton.addDiskStateListener(new OnDiskStateChangeListener() {
            @Override
            public void onDiskFind() {
                Log.d(Control.TAG, "onDiskFind");
            }

            @Override
            public void onDiskReady() {
                Log.d(Control.TAG, "onDiskReady");
                DVDFile root = new DVDFile();
                travel(root);
            }
        });
        DVDManagerService.Singleton.control.setContext(InstrumentationRegistry.getContext());
        DVDManagerService.Singleton.connect();
        LockSupport.park();
    }


    public void travel(DVDFile root) {
        try {
            for (DVDFile f : root.listFiles()) {
                travel(f);
            }

            // file
            if (!root.isDir()) {
                Log.e(Control.TAG, root.getName());
                Log.d(Control.TAG, root.getPath());
                Log.d(Control.TAG, root.getUrl());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
