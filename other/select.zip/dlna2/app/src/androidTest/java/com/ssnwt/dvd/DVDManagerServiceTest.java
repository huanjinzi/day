package com.ssnwt.dvd;

import android.util.Log;

import org.junit.Test;

import java.io.IOException;

public class DVDManagerServiceTest {

    @Test
    public void connectTest() throws Exception {

        DVDManagerService dvd = DVDManagerService.Singleton;
        dvd.addConnectedListener(new ConnectionListener() {
            @Override
            public void onSuccess() {
                Log.d("ConnectionListener","onSuccess");
            }

            @Override
            public void onTimeout() {
                Log.d("ConnectionListener","onTimeout");
            }

            @Override
            public void onError() {
                Log.d("ConnectionListener","onError");
            }
        });

        dvd.addDiskStateListener(new OnDiskStateChangeListener() {
            @Override
            public void onDiskFind() {

            }

            @Override
            public void onDiskReady() {
                DVDFile root = new DVDFile();
                travel(root);
            }
        });

        dvd.addConnectedListener(new ConnectionListener() {
            @Override
            public void onSuccess() {
                Log.d("huanjinzi", "onSuccess");
            }

            @Override
            public void onTimeout() {
                Log.d("huanjinzi", "onTimeout");
            }

            @Override
            public void onError() {
                Log.d("huanjinzi", "onError");
            }
        });
        dvd.connect();
        dvd.main.join();
    }

    public void travel(DVDFile root) {
        try {
            for (DVDFile f : root.listFiles()) {
                travel(f);
            }

            // file
            if (!root.isDir()) {
                Log.d("DVD", root.getName());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void connect() {
    }

    @Test
    public void destroy() {
    }


}
