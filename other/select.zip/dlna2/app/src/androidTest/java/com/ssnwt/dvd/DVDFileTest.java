package com.ssnwt.dvd;

import org.junit.Test;

public class DVDFileTest {

    @Test
    public void getPath() {
        DVDFile file = new DVDFile();
        file.setPath("/");
        file.setPath("/..");
        file.setPath("/ss/aa/../bb/");
        file.setPath("/ss/aa/../bb");
        file.setPath("ss/aa/../bb/");
        file.setPath("ss/aa/../bb");
        file.setPath("./../ss/aa/../bb/.");
    }
}




