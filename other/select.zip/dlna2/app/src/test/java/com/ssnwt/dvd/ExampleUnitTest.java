package com.ssnwt.dvd;

import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.concurrent.locks.LockSupport;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {

    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void finallyTest() {
        try {
            throwEx();
            return;
        } catch (Exception e) {
            System.out.println("catch");
            return;
        } finally {
            System.out.println("finally");
        }

    }


    public void throwEx() throws Exception {
        throw new Exception();
    }

    private OkHttpClient client;

    @Before
    public void init() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        client = builder.build();
    }

    //@Test
    public void HttpProtocol() throws Exception {
        String url = "http://192.168.1.1:8080/课程4（嵌入式LINUX内核驱动进阶班-下）/第3天（嵌入式Linux系统构建）/国嵌内核驱动进阶班-3-4（嵌入式文件系统）.avi";
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();

        File file = new File("linux.avi");
        try (ResponseBody body = response.body();
             InputStream in = body.byteStream();
             OutputStream os = new FileOutputStream(file)
        ) {
            byte[] buffer = new byte[1024 * 10];
            int len;

            while ((len = in.read(buffer)) != -1) {
                os.write(buffer, 0, len);
            }
        }

    }


    @Test
    public void FileTest() {
        for (String s : get()) {

        }
    }

    String[] get(){
        return new String[0];
    }


    @Test
    public void ArrayTest() throws Exception{
        Integer[] obj = new Integer[10];

        Class cls = Array.class;
        Method getLength = cls.getMethod("getLength", Object.class);

        Object value = getLength.invoke(null, (Object) obj);
        System.out.println(value);
    }


    @Test
    public void ss() {
        System.out.println(getType("123.mp4"));
        System.out.println(getType("123.mp4"));
        System.out.println(getType("123.mp4.mp3"));
        System.out.println(getType(".mp4"));
    }

    public String getType(String name) {

        String fileName = name;
            String[] seq = fileName.split("[.]");

            if (seq.length >= 2) {
                return seq[seq.length -1];
            }

        return null;
    }



    @Test
    public void matrix() {

    }

    @Test
    public void park() throws Exception {
        final Object lock = new Object();
        Runnable run = new Runnable() {
            @Override
            public void run() {
                System.out.println("park");
                synchronized (lock) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("unpark success");
            }
        };

        Thread thread = new Thread(run);
        thread.start();

        Thread.sleep(3000);

        synchronized (lock) {
            lock.notify();
        }
        System.out.println("unpark");

        Thread.sleep(10000);
    }

    @Test
    public void res() throws Exception {
        URL url1 = getClass().getClassLoader().getResource("icon.png");
        URL url2 = getClass().getResource("/icon.png");

        System.out.println(resolveName("icon.png", getClass()));
        System.out.println(resolveName("/icon.png", getClass()));

        System.out.println(url1);
        System.out.println(url2);
    }


    private String resolveName(String name,Class cls) {
        if (name == null) {
            return name;
        }
        if (!name.startsWith("/")) {
            Class<?> c = cls;
            while (c.isArray()) {
                c = c.getComponentType();
            }
            String baseName = c.getName();
            int index = baseName.lastIndexOf('.');
            if (index != -1) {
                name = baseName.substring(0, index).replace('.', '/')
                        +"/"+name;
            }
        } else {
            name = name.substring(1);
        }
        return name;
    }
}

